# Anonymized supplementary material

- `prereg/e1_e5_protocol_v0.json` — frozen E1–E5 protocol (preregistration), as referenced in the paper.
- `tiny_full/` — Tiny-CDLR smoke tests (Appendix A, P1–P2).
- `continual/` — local adapter vs. BPTT stream (Appendix A, P3).
- `arena/` — small unmatched-budget comparison (Appendix A, P4).
- `e2_capacity/` — E2 PILOT toy capacity sweep (Figure 3, Table 3, Appendix A P5). Toy width n ≤ 4096, synthetic keys, no trained encoder; regime characterisation only. Run: `python e2_capacity.py --mode sweep` (~41 s, 8 CPU threads).

The BDH backbone is the unmodified public `bdh.py` released by the BDH authors; it is not redistributed here.
These are CPU smoke tests only. Apart from the E2 PILOT (a labelled toy regime characterisation), they support no main-text claim.

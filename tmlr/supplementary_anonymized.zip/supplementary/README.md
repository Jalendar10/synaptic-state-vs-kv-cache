# Anonymized supplementary material

- `prereg/e1_e5_protocol_v0.json` — frozen E1–E5 protocol (preregistration), as referenced in the paper.
- `tiny_full/` — Tiny-CDLR smoke tests (Appendix A, P1–P2).
- `continual/` — local adapter vs. BPTT stream (Appendix A, P3).
- `arena/` — small unmatched-budget comparison (Appendix A, P4).

The BDH backbone is the unmodified public `bdh.py` released by the BDH authors; it is not redistributed here.
These are CPU smoke tests only and support no main-text claim.

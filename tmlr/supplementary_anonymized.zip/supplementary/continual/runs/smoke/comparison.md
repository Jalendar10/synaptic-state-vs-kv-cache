# Continual comparison (A→B→A, seeds=[0])

Research prototype — does not claim to close BDH §7.2 gap.

| mode | avg online loss | avg online acc | forget gap (loss↑) | forget gap (acc↓) | acc on B @end B | relearn first-k loss | acc on A @end | per-phase online loss | wall s | ms/step |
|---|---|---|---|---|---|---|---|---|---|---|
| frozen | 3.498 | 0.023 | 0.000 | 0.000 | 0.068 | 3.523 | 0.000 | 3.526 / 3.442 / 3.525 | 0.12 | 1.3 |
| bptt | 2.044 | 0.540 | 1.131 | 0.886 | 0.943 | 2.209 | 1.000 | 2.322 / 2.378 / 1.431 | 0.26 | 2.9 |
| hebbian | 1.586 | 0.634 | 2.450 | 0.932 | 0.972 | 2.074 | 1.000 | 1.615 / 2.018 / 1.125 | 0.13 | 1.4 |

Pretrain (BPTT on task P, 60 steps): eval loss 2.412, acc 1.000. Chance acc = 0.031, chance loss = ln(32) = 3.466.
Forget gap = first task's held-out metric right after phase 2 minus end of phase 1.

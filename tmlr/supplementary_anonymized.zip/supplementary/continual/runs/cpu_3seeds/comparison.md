# Continual comparison (A→B→A, seeds=[0, 1, 2])

Research prototype — does not claim to close BDH §7.2 gap.

| mode | avg online loss | avg online acc | forget gap (loss↑) | forget gap (acc↓) | acc on B @end B | relearn first-k loss | acc on A @end | per-phase online loss | wall s | ms/step |
|---|---|---|---|---|---|---|---|---|---|---|
| frozen | 7.214 ± 0.100 | 0.021 ± 0.000 | 0.000 ± 0.000 | 0.000 ± 0.000 | 0.061 ± 0.006 | 7.373 ± 0.109 | 0.000 ± 0.000 | 7.369 / 6.906 / 7.367 | 1.23 | 2.7 |
| bptt | 0.443 ± 0.010 | 0.914 ± 0.002 | 6.962 ± 0.202 | 0.970 ± 0.009 | 1.000 ± 0.000 | 1.981 ± 0.098 | 1.000 ± 0.000 | 0.521 / 0.518 / 0.289 | 3.40 | 7.5 |
| hebbian | 0.824 ± 0.004 | 0.809 ± 0.001 | 7.610 ± 0.142 | 0.970 ± 0.009 | 1.000 ± 0.000 | 4.182 ± 0.069 | 1.000 ± 0.000 | 0.960 / 0.861 / 0.651 | 1.47 | 3.3 |
| local_head | 1.686 ± 0.010 | 0.551 ± 0.001 | 2.100 ± 0.046 | 0.970 ± 0.009 | 1.000 ± 0.000 | 1.954 ± 0.028 | 1.000 ± 0.000 | 2.542 / 1.805 / 0.710 | 1.33 | 3.0 |

Pretrain (BPTT on task P, 300 steps): eval loss 0.023, acc 1.000. Chance acc = 0.031, chance loss = ln(32) = 3.466.
Forget gap = first task's held-out metric right after phase 2 minus end of phase 1.

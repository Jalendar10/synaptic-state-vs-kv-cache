"""Local learning rules for the adapter (no autograd, no BPTT).

All updates use only quantities available at the synapse at time t:
  pre  = phi_t   : BDH last-layer neuron activations xy_sparse (>= 0), L2-normalised
  post = p_t     : adapter output distribution (softmax of logits)
  teach= y_t     : one-hot target (a clamped postsynaptic "teacher" signal)

Rule 1 — slow head W (V x F), three-factor delta / eligibility rule:
    e_t   = gamma * e_{t-1} + phi_t            (forward-only presynaptic trace,
                                                within a window, never back-propagated)
    dW    = eta_W * mean_{b,t}[ (y_t - p_t) (outer) e_t ] - eta_W * wd * W
    db    = eta_W * mean_{b,t}[ y_t - p_t ]
  With gamma = 0 this is the classic delta (Widrow-Hoff / softmax-LMS) rule, which
  equals the exact cross-entropy gradient of a *linear head only*; nothing flows
  into the backbone or back through time.

Rule 2 — fast Hebbian memory M (V x F), Oja's rule with clamped teacher activity:
    M    <- lambda * M
    dm_i  = eta_M * mean_{b,t}[ y_{t,i} * (phi_t - y_{t,i} * m_i) ]
  Each row m_i converges toward the (unit-norm-bounded) mean feature of class i;
  lambda < 1 damps old associations (as BDH §6.1 notes damping is needed).
    logits_t = W phi_t + b + alpha * M phi_t
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def normalise(phi: torch.Tensor, eps: float) -> torch.Tensor:
    return phi / (phi.norm(dim=-1, keepdim=True) + eps)


def eligibility_trace(phi: torch.Tensor, gamma: float) -> torch.Tensor:
    """phi: (B, T, F) -> e: (B, T, F), e_t = gamma*e_{t-1} + phi_t (causal, forward only)."""
    if gamma == 0.0:
        return phi
    e = torch.empty_like(phi)
    acc = torch.zeros_like(phi[:, 0])
    for t in range(phi.shape[1]):
        acc = gamma * acc + phi[:, t]
        e[:, t] = acc
    return e


@torch.no_grad()
def delta_rule_update(W, b, phi, probs, y, mask, lr, wd, gamma):
    """W:(V,F) b:(V,) phi:(B,T,F) probs:(B,T,V) y:(B,T) long, mask:(B,T) bool."""
    V = W.shape[0]
    e = eligibility_trace(phi, gamma)[mask]                       # (n, F)
    err = F.one_hot(y[mask], V).float() - probs[mask]             # (n, V)  post-error
    n = max(1, err.shape[0])
    W.add_(lr * (err.T @ e) / n - lr * wd * W)
    b.add_(lr * err.mean(0))


@torch.no_grad()
def oja_memory_update(M, phi, y, mask, lr, decay):
    """M:(V,F). Oja: dm_i = lr * y_i (phi - y_i m_i), y one-hot teacher."""
    V = M.shape[0]
    M.mul_(decay)
    ph = phi[mask]                                                # (n, F)
    yo = F.one_hot(y[mask], V).float()                            # (n, V)
    n = max(1, ph.shape[0])
    hebb = yo.T @ ph                                              # sum_t y_i phi
    oja = (yo * yo).sum(0, keepdim=True).T * M                    # sum_t y_i^2 m_i
    M.add_(lr * (hebb - oja) / n)

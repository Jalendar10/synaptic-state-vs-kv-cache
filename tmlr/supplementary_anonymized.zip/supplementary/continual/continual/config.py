"""Configuration + presets for the continual comparison."""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field


@dataclass
class ContinualConfig:
    # ---- backbone: tiny Pathway BDH (imported unchanged) ----
    bdh_n_layer: int = 2
    bdh_n_embd: int = 64
    bdh_n_head: int = 2
    bdh_mlp_mult: int = 16          # N = mult*D/nh neurons per head; features = nh*N
    # ---- task stream ----
    n_keys: int = 32                # vocabulary = keys = values
    seq_len: int = 16               # window length T (also the BPTT window)
    lag: int = 1                    # target y_t = pi_task(x_{t-lag}) -> needs context
    phases: list = field(default_factory=lambda: ["A", "B", "A"])
    pretrain_task: str = "P"        # backbone is pretrained (BPTT) on a separate map
    task_seeds: dict = field(default_factory=lambda: {"P": 101, "A": 202, "B": 303})
    # ---- budget ----
    batch_size: int = 16
    pretrain_steps: int = 300
    steps_per_phase: int = 150
    eval_batches: int = 4
    eval_every: int = 25
    relearn_k: int = 20             # "relearning speed": mean online loss of first k steps of phase 3
    # ---- pretraining / BPTT mode (upper bound) ----
    pretrain_lr: float = 3e-3
    bptt_lr: float = 1e-3
    bptt_head_lr: float = 1e-2
    # ---- Hebbian / local adapter (method under test) ----
    feat_norm_eps: float = 1e-6
    head_lr: float = 2.0            # eta_W, local delta rule on slow head
    head_decay: float = 1e-4        # weight decay on slow head
    trace_gamma: float = 0.0        # eligibility trace decay (0 = pure pre*post-error)
    mem_lr: float = 0.5             # eta_M, Oja rule on fast Hebbian memory
    mem_decay: float = 0.99         # lambda, per-step damping of fast memory
    mem_alpha: float = 16.0         # read gain of fast memory into logits
    # ---- misc ----
    seed: int = 0
    device: str = "cpu"
    threads: int = 4

    @property
    def n_features(self) -> int:
        N = self.bdh_mlp_mult * self.bdh_n_embd // self.bdh_n_head
        return self.bdh_n_head * N

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


PRESETS = {
    "smoke": dict(bdh_n_embd=32, bdh_mlp_mult=8, seq_len=12, batch_size=8,
                  pretrain_steps=60, steps_per_phase=30, eval_batches=2,
                  eval_every=10, relearn_k=10),
    "cpu": dict(),
    "long": dict(bdh_n_layer=3, bdh_n_embd=96, bdh_n_head=4, bdh_mlp_mult=16,
                 seq_len=32, batch_size=32, pretrain_steps=1500,
                 steps_per_phase=600, eval_batches=8, eval_every=50, relearn_k=50,
                 phases=["A", "B", "A", "B"]),
}


def make_config(preset: str = "cpu", **overrides) -> ContinualConfig:
    kw = dict(PRESETS[preset])
    kw.update({k: v for k, v in overrides.items() if v is not None})
    return ContinualConfig(**kw)

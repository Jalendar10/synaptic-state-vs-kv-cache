"""Run frozen / BPTT / Hebbian modes on the same continual stream; write metrics.

Protocol (identical for every mode, same seed, same batches):
  1. Pretrain backbone + head with BPTT on task P (shared checkpoint).
  2. Stream phases (default A -> B -> A). Each step: prequential eval
     (loss/acc on the incoming batch BEFORE updating), then the mode's update.
  3. Held-out eval on every task at intervals and at the end of each phase.

Usage:
  python -m continual.train_compare --preset cpu --seeds 0 1 2
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from pathlib import Path

import torch

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from continual.adapter import AdaptedBDH, masked_ce  # noqa: E402
from continual.config import make_config  # noqa: E402
from continual.tasks import TaskStream  # noqa: E402

MODES = ["frozen", "bptt", "hebbian"]
# optional ablation (not run by default): local delta-rule head only, no fast Oja memory
EXTRA_MODES = ["local_head"]


@torch.no_grad()
def evaluate(model, stream):
    out = {}
    for name in stream.eval_tasks:
        ls, ac = [], []
        for x, y in stream.eval_sets[name]:
            loss, acc = masked_ce(model(x), y)
            ls.append(loss.item()); ac.append(acc.item())
        out[name] = {"loss": sum(ls) / len(ls), "acc": sum(ac) / len(ac)}
    return out


def pretrain(cfg, stream):
    torch.manual_seed(cfg.seed)
    model = AdaptedBDH(cfg)
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=cfg.pretrain_lr)
    g = stream.train_gen(offset=0)
    t0 = time.time()
    for _ in range(cfg.pretrain_steps):
        x, y = stream.batch(cfg.pretrain_task, g)
        loss, acc = masked_ce(model(x), y)
        opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        ls, ac = zip(*[(lambda r: (r[0].item(), r[1].item()))(masked_ce(model(x), y))
                       for x, y in stream.eval_sets[cfg.pretrain_task]])
    info = {"task": cfg.pretrain_task, "steps": cfg.pretrain_steps,
            "eval_loss": sum(ls) / len(ls), "eval_acc": sum(ac) / len(ac),
            "wall_s": time.time() - t0}
    return model, info


def run_mode(mode, base_model, cfg, stream):
    model = copy.deepcopy(base_model)
    model.cfg = cfg                       # adapter hyper-params come from this run's cfg
    model.use_mem = mode == "hebbian"
    opt = None
    if mode == "bptt":
        # standard backprop through the full T-token window, backbone + head
        opt = torch.optim.Adam([
            {"params": model.backbone_params(), "lr": cfg.bptt_lr},
            {"params": [model.W, model.b], "lr": cfg.bptt_head_lr},
        ])
    else:
        model.requires_grad_(False)
    if mode not in MODES + EXTRA_MODES:
        raise ValueError(mode)
    g = stream.train_gen(offset=1)        # same batches for every mode
    phases, curve, step = [], [], 0
    t_mode = time.time()
    curve.append({"step": 0, "phase": -1, "eval": evaluate(model, stream)})
    for pi, task in enumerate(cfg.phases):
        online_l, online_a = [], []
        t0 = time.time()
        for s in range(cfg.steps_per_phase):
            x, y = stream.batch(task, g)
            if mode == "frozen":
                with torch.no_grad():
                    l, a = masked_ce(model(x), y)
                l, a = l.item(), a.item()
            elif mode == "bptt":
                loss, acc = masked_ce(model(x), y)          # prequential: before update
                opt.zero_grad(); loss.backward(); opt.step()
                l, a = loss.item(), acc.item()
            else:                                           # hebbian / local_head
                l, a = model.local_step(x, y)               # prequential: before update
            online_l.append(l); online_a.append(a); step += 1
            if step % cfg.eval_every == 0:
                curve.append({"step": step, "phase": pi, "eval": evaluate(model, stream)})
        phases.append({
            "index": pi, "task": task,
            "online_loss": sum(online_l) / len(online_l),
            "online_acc": sum(online_a) / len(online_a),
            "first_k_online_loss": sum(online_l[:cfg.relearn_k]) / len(online_l[:cfg.relearn_k]),
            "end_eval": evaluate(model, stream),
            "wall_s": time.time() - t0,
        })
    wall = time.time() - t_mode
    return {"mode": mode, "phases": phases, "curve": curve, "summary": summarise(phases, cfg),
            "wall_s": wall, "ms_per_step": 1000 * wall / max(1, step)}


def summarise(phases, cfg):
    first = phases[0]["task"]
    s = {"first_task": first}
    # forgetting: first task evaluated right after the next (different) phase vs end of its own phase
    nxt = next((p for p in phases[1:] if p["task"] != first), None)
    if nxt is not None:
        e1, e2 = phases[0]["end_eval"][first], nxt["end_eval"][first]
        s["forgetting_gap_loss"] = e2["loss"] - e1["loss"]     # >0 = forgot
        s["forgetting_gap_acc"] = e1["acc"] - e2["acc"]        # >0 = forgot
        s["plasticity_acc_new_task"] = nxt["end_eval"][nxt["task"]]["acc"]
        s["plasticity_loss_new_task"] = nxt["end_eval"][nxt["task"]]["loss"]
    ret = next((p for p in phases[2:] if p["task"] == first), None)
    if ret is not None:
        s["relearn_first_k_online_loss"] = ret["first_k_online_loss"]
        s["original_first_k_online_loss"] = phases[0]["first_k_online_loss"]
        s["final_acc_first_task"] = ret["end_eval"][first]["acc"]
    s["avg_online_loss"] = sum(p["online_loss"] for p in phases) / len(phases)
    s["avg_online_acc"] = sum(p["online_acc"] for p in phases) / len(phases)
    s["final_eval"] = phases[-1]["end_eval"]
    return s


def run_compare(cfg, modes=MODES):
    torch.set_num_threads(cfg.threads)
    stream = TaskStream(cfg)
    base, pinfo = pretrain(cfg, stream)
    return {"seed": cfg.seed, "pretrain": pinfo,
            "modes": {m: run_mode(m, base, cfg, stream) for m in modes}}


KEYS = [("avg_online_loss", "avg online loss"), ("avg_online_acc", "avg online acc"),
        ("forgetting_gap_loss", "forget gap (loss↑)"), ("forgetting_gap_acc", "forget gap (acc↓)"),
        ("plasticity_acc_new_task", "acc on B @end B"),
        ("relearn_first_k_online_loss", "relearn first-k loss"),
        ("final_acc_first_task", "acc on A @end")]


def aggregate(results):
    agg = {}
    for m in results[0]["modes"]:
        rows = [r["modes"][m] for r in results]
        d = {}
        for k, _ in KEYS:
            vals = [r["summary"][k] for r in rows if k in r["summary"]]
            if vals:
                mu = sum(vals) / len(vals)
                sd = (sum((v - mu) ** 2 for v in vals) / max(1, len(vals) - 1)) ** 0.5
                d[k] = {"mean": mu, "std": sd, "n": len(vals)}
        d["wall_s"] = {"mean": sum(r["wall_s"] for r in rows) / len(rows)}
        d["ms_per_step"] = {"mean": sum(r["ms_per_step"] for r in rows) / len(rows)}
        d["per_phase_online_loss"] = [sum(r["phases"][i]["online_loss"] for r in rows) / len(rows)
                                      for i in range(len(rows[0]["phases"]))]
        agg[m] = d
    return agg


def to_markdown(agg, cfg, results):
    phases = "→".join(cfg.phases)
    lines = [f"# Continual comparison ({phases}, seeds={[r['seed'] for r in results]})", "",
             "Research prototype — does not claim to close BDH §7.2 gap.", "",
             "| mode | " + " | ".join(lbl for _, lbl in KEYS) + " | per-phase online loss | wall s | ms/step |",
             "|---|" + "---|" * (len(KEYS) + 3)]
    for m, d in agg.items():
        cells = []
        for k, _ in KEYS:
            if k in d:
                v = d[k]
                cells.append(f"{v['mean']:.3f}" + (f" ± {v['std']:.3f}" if v["n"] > 1 else ""))
            else:
                cells.append("–")
        pp = " / ".join(f"{v:.3f}" for v in d["per_phase_online_loss"])
        lines.append(f"| {m} | " + " | ".join(cells) + f" | {pp} | {d['wall_s']['mean']:.2f} | {d['ms_per_step']['mean']:.1f} |")
    pre = results[0]["pretrain"]
    lines += ["", f"Pretrain (BPTT on task {pre['task']}, {pre['steps']} steps): eval loss "
              f"{pre['eval_loss']:.3f}, acc {pre['eval_acc']:.3f}. Chance acc = {1 / cfg.n_keys:.3f}, "
              f"chance loss = ln({cfg.n_keys}) = {torch.log(torch.tensor(float(cfg.n_keys))).item():.3f}.",
              "Forget gap = first task's held-out metric right after phase 2 minus end of phase 1."]
    return "\n".join(lines) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="cpu")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--modes", nargs="+", default=MODES)
    ap.add_argument("--steps-per-phase", type=int)
    ap.add_argument("--pretrain-steps", type=int)
    ap.add_argument("--trace-gamma", type=float)
    ap.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    ov = dict(steps_per_phase=a.steps_per_phase, pretrain_steps=a.pretrain_steps,
              trace_gamma=a.trace_gamma)
    results = []
    for s in a.seeds:
        cfg = make_config(a.preset, seed=s, **ov)
        print(f"[seed {s}] preset={a.preset} features={cfg.n_features}", flush=True)
        results.append(run_compare(cfg, a.modes))
    agg = aggregate(results)
    out = Path(a.out or Path(__file__).resolve().parents[1] / "runs" / f"compare_{a.preset}_{time.strftime('%Y%m%d_%H%M%S')}")
    out.mkdir(parents=True, exist_ok=True)
    (out / "metrics.json").write_text(json.dumps({"config": cfg.to_dict(), "aggregate": agg,
                                                  "runs": results}, indent=2))
    md = to_markdown(agg, cfg, results)
    (out / "comparison.md").write_text(md)
    print(md); print(f"wrote {out}")
    return out, agg


if __name__ == "__main__":
    main()

"""Tiny CPU smoke run: all three modes, writes runs/smoke/{metrics.json,comparison.md}."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if __package__ in (None, ""):
    sys.path.insert(0, str(ROOT))

import torch  # noqa: E402

from continual import hebbian_update as hu  # noqa: E402
from continual.train_compare import MODES, main  # noqa: E402


def unit_checks():
    # Oja row converges toward unit-norm mean feature; delta rule reduces loss.
    torch.manual_seed(0)
    M = torch.zeros(2, 4)
    phi = hu.normalise(torch.rand(1, 50, 4) + torch.tensor([2.0, 0, 0, 0]), 1e-6)
    y = torch.zeros(1, 50, dtype=torch.long); mask = torch.ones(1, 50, dtype=torch.bool)
    for _ in range(200):
        hu.oja_memory_update(M, phi, y, mask, lr=0.5, decay=1.0)
    assert 0.8 < M[0].norm() <= 1.01 and M[1].abs().sum() == 0, M
    W, b = torch.zeros(2, 4), torch.zeros(2)
    l0 = None
    for _ in range(50):
        lg = phi @ W.T + b
        l = torch.nn.functional.cross_entropy(lg[mask], y[mask]).item()
        l0 = l if l0 is None else l0
        hu.delta_rule_update(W, b, phi, lg.softmax(-1), y, mask, 0.5, 0.0, 0.0)
    assert l < l0, (l0, l)
    e = hu.eligibility_trace(torch.ones(1, 3, 2), 0.5)
    assert torch.allclose(e[0, :, 0], torch.tensor([1.0, 1.5, 1.75]))


def run():
    unit_checks()
    out, agg = main(["--preset", "smoke", "--seeds", "0", "--out", str(ROOT / "runs" / "smoke")])
    m = json.loads((out / "metrics.json").read_text())
    assert set(m["aggregate"]) == set(MODES)
    for mode in MODES:
        s = m["runs"][0]["modes"][mode]["summary"]
        for k in ["avg_online_loss", "forgetting_gap_loss", "forgetting_gap_acc"]:
            assert math.isfinite(s[k]), (mode, k)
    assert (out / "comparison.md").exists()
    print("SMOKE OK")


if __name__ == "__main__":
    run()

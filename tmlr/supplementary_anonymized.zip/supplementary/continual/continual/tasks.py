"""Continual task stream: shifting key->value maps.

Each task is a random permutation pi of {0..K-1}. A sample is a random token
sequence x_0..x_{T-1}; the target at position t (t >= lag) is pi(x_{t-lag}).
Because target depends on a *previous* token, the predictor must use BDH's
attention context (BDH attention is strictly causal, tril(diagonal=-1)).

Tasks A and B share inputs but map them to different outputs => direct
interference, the classic setting for catastrophic forgetting.
"""
from __future__ import annotations

import torch


class KVTask:
    def __init__(self, name: str, n_keys: int, seed: int):
        self.name = name
        g = torch.Generator().manual_seed(seed)
        self.perm = torch.randperm(n_keys, generator=g)
        self.n_keys = n_keys

    def sample(self, batch: int, T: int, lag: int, g: torch.Generator):
        x = torch.randint(0, self.n_keys, (batch, T), generator=g)
        y = torch.full_like(x, -100)                # -100 = ignore index
        y[:, lag:] = self.perm[x[:, :-lag]] if lag > 0 else self.perm[x]
        return x, y


class TaskStream:
    """Phases (e.g. A, B, A) + fixed held-out eval sets per task."""

    def __init__(self, cfg):
        self.cfg = cfg
        names = set(cfg.phases) | {cfg.pretrain_task}
        self.tasks = {n: KVTask(n, cfg.n_keys, cfg.task_seeds[n]) for n in sorted(names)}
        ge = torch.Generator().manual_seed(10_000 + cfg.seed)
        self.eval_sets = {
            n: [t.sample(cfg.batch_size, cfg.seq_len, cfg.lag, ge) for _ in range(cfg.eval_batches)]
            for n, t in self.tasks.items()
        }

    def train_gen(self, offset: int = 0) -> torch.Generator:
        return torch.Generator().manual_seed(20_000 + 97 * self.cfg.seed + offset)

    def batch(self, name: str, g: torch.Generator):
        return self.tasks[name].sample(self.cfg.batch_size, self.cfg.seq_len, self.cfg.lag, g)

    @property
    def eval_tasks(self):
        return sorted(set(self.cfg.phases))

"""Backbone (Pathway BDH, imported unchanged) + adapter head / fast Hebbian memory."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from torch import nn

from continual import hebbian_update as hu

_BDH_DIR = Path(os.environ.get("CONTINUAL_BDH_PATH",
                               Path(__file__).resolve().parents[2] / "code" / "bdh"))
if str(_BDH_DIR) not in sys.path:
    sys.path.insert(0, str(_BDH_DIR))
import bdh as _bdh  # noqa: E402  Pathway Technology, Inc. — used as-is


def _store_last(module, inp, out):
    module._last_out = out


class AdaptedBDH(nn.Module):
    """phi = L2norm(last-layer xy_sparse of BDH); logits = W phi + b + alpha * M phi.

    BDH's own lm_head is not used (frozen, excluded from optimisers); the readout is
    our adapter head so all three modes share one architecture.
    """

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        bcfg = _bdh.BDHConfig(n_layer=cfg.bdh_n_layer, n_embd=cfg.bdh_n_embd, dropout=0.0,
                              n_head=cfg.bdh_n_head, mlp_internal_dim_multiplier=cfg.bdh_mlp_mult,
                              vocab_size=cfg.n_keys)
        self.bdh = _bdh.BDH(bcfg)
        self.bdh.lm_head.requires_grad_(False)
        V, Fd = cfg.n_keys, cfg.n_features
        self.W = nn.Parameter(torch.randn(V, Fd) * 0.01)
        self.b = nn.Parameter(torch.zeros(V))
        self.register_buffer("M", torch.zeros(V, Fd))       # fast Hebbian memory
        self.use_mem = False
        # BDH.drop is applied to xy_sparse once per layer; the last call = last layer.
        # The hook stores on the drop module itself so deepcopy()'d models stay correct.
        self.bdh.drop.register_forward_hook(_store_last)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        self.bdh(x)
        xy = self.bdh.drop._last_out                        # (B, nh, T, N) >= 0
        self.bdh.drop._last_out = None
        B, nh, T, N = xy.shape
        phi = xy.transpose(1, 2).reshape(B, T, nh * N)
        return hu.normalise(phi, self.cfg.feat_norm_eps)

    def logits(self, phi: torch.Tensor) -> torch.Tensor:
        out = phi @ self.W.T + self.b
        if self.use_mem:
            out = out + self.cfg.mem_alpha * (phi @ self.M.T)
        return out

    def forward(self, x):
        return self.logits(self.features(x))

    def backbone_params(self):
        return [p for n, p in self.bdh.named_parameters() if p.requires_grad]

    # ---- local (Hebbian) step: no autograd anywhere ----
    @torch.no_grad()
    def local_step(self, x, y):
        c = self.cfg
        phi = self.features(x)
        logits = self.logits(phi)
        mask = y != -100
        loss = F.cross_entropy(logits[mask], y[mask])
        acc = (logits[mask].argmax(-1) == y[mask]).float().mean()
        probs = logits.softmax(-1)
        hu.delta_rule_update(self.W.data, self.b.data, phi, probs, y, mask,
                             c.head_lr, c.head_decay, c.trace_gamma)
        if self.use_mem:
            hu.oja_memory_update(self.M, phi, y, mask, c.mem_lr, c.mem_decay)
        return loss.item(), acc.item()


def masked_ce(logits, y):
    mask = y != -100
    loss = F.cross_entropy(logits[mask], y[mask])
    acc = (logits[mask].argmax(-1) == y[mask]).float().mean()
    return loss, acc

"""Hebbian Continual Adapter — Phase 3 of ALRS -> Arena -> Continual Adapter.

Research prototype. Does NOT claim to close the BDH paper's no-BPTT loss gap (§7.2).
"""
__version__ = "0.1.0"

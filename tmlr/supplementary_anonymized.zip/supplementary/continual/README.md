# Hebbian Continual Adapter — Phase 3 (final)

**ALRS → Arena → Continual Adapter.** Phase 1 (`../alrs`) built an inference-time
Hebbian-memory learner; Phase 2 (`../arena`) built a matched-scale architecture
harness. Phase 3 asks: *can a BDH backbone adapt online to a shifting task stream
using only local (Hebbian / eligibility-style) learning signals, with no
backpropagation through time?*

> **Research prototype.** This does **NOT** claim to close, or even measure, the gap
> reported in the BDH paper. It is a toy continual-learning testbed on a synthetic
> key→value stream with a tiny BDH, and the Hebbian hyper-parameters were tuned by
> hand on seed 0 of the `cpu` preset.

## Motivation

[B] Kosowski et al., *The Dragon Hatchling* (BDH), arXiv:2509.26507, **§7.2**: training
BDH without backpropagation through time raises loss (roughly 0.65 → 0.75–1.05 in their
setting). Local, biologically-plausible signals are attractive for online adaptation
because they need no stored activations and no backward pass through the sequence.
This project tests one narrow version of that idea: **keep the backbone fixed and
adapt only a readout + a fast Hebbian memory on top of BDH neuron activations,
using local rules**, and compares it with a frozen model and with standard backprop.

## What is compared (same seed, same pretrained checkpoint, same batches)

| mode | what updates | how |
|---|---|---|
| `frozen` | nothing | lower bound for plasticity / no forgetting by construction |
| `bptt` | BDH backbone + head | Adam, standard backprop through the full T-token window (**upper bound**) |
| `hebbian` | head W,b + fast memory M | **local rules below, `torch.no_grad()`, no autograd at all** (method under test) |
| `local_head` (ablation, opt-in) | head W,b only | delta rule only, no fast memory |

Backbone: Pathway BDH from `../code/bdh/bdh.py`, **imported unchanged** (path override:
`CONTINUAL_BDH_PATH`). Features φ_t = L2-normalised last-layer `xy_sparse`
(B, nh·N, ≥0), captured with a forward hook on `BDH.drop`; BDH's own `lm_head` is
unused. All modes share the readout `logits_t = W φ_t + b (+ α M φ_t for hebbian)`.

## The exact local rule (`continual/hebbian_update.py`)

Per step, for every (non-ignored) position t of the incoming batch; pre = φ_t,
post = p_t = softmax(logits_t), teacher = y_t (one-hot target):

1. **Slow head, three-factor delta / eligibility rule**
   ```
   e_t = γ·e_{t-1} + φ_t                     (forward-only presynaptic trace; never back-propagated)
   W  += η_W · mean_t[(y_t − p_t) ⊗ e_t] − η_W·wd·W
   b  += η_W · mean_t[y_t − p_t]
   ```
   With γ = 0 (default) this is the classic delta / softmax-LMS rule. Note honestly:
   for a *linear head alone* it coincides with the cross-entropy gradient of that head;
   what makes it "local" is that nothing flows into the backbone or back through time.
2. **Fast Hebbian memory, Oja's rule with clamped teacher activity**
   ```
   M   ← λ·M                                (damping, cf. BDH §6.1)
   m_i += η_M · mean_t[y_{t,i}·(φ_t − y_{t,i}·m_i)]
   ```
   Each row m_i tracks the (norm-bounded) mean feature of class i; read with gain α.

Defaults (`config.py`): η_W = 2.0, wd = 1e-4, γ = 0.0, η_M = 0.5, λ = 0.99, α = 16.

## Task stream (`continual/tasks.py`)

Each task is a random permutation π of K = 32 tokens. Input: random token sequence;
target at position t is **π(x_{t−1})** (lag 1), so the predictor must use BDH's
(strictly causal) attention context. Stream: pretrain on task P (BPTT, shared
checkpoint) → **A → B → A** (`long` preset: A → B → A → B). A and B use the same inputs
with different outputs: direct interference. Every step is **prequential** (loss/acc
on the incoming batch *before* the update); held-out eval sets per task are scored
every `eval_every` steps and at the end of each phase.

## Metrics (`runs/*/metrics.json`, `comparison.md`)

* `avg_online_loss / acc` — per phase and averaged (prequential)
* **forgetting gap** — task A held-out loss (acc) right after phase B minus (before)
  the end of phase A. >0 = forgot.
* plasticity — acc on B at the end of phase B
* relearning — mean online loss over the first k steps of the return to A
* final held-out acc on every task; wall time and ms/step per mode; full eval curves

## Results so far

`smoke` (1 seed, ~2 s, `runs/smoke/`):

| mode | avg online loss | avg online acc | forget gap (loss) | forget gap (acc) | acc B @end B | wall s |
|---|---|---|---|---|---|---|
| frozen | 3.498 | 0.023 | 0.000 | 0.000 | 0.068 | 0.12 |
| bptt | 2.044 | 0.540 | 1.131 | 0.886 | 0.943 | 0.29 |
| hebbian | 1.586 | 0.634 | 2.450 | 0.932 | 0.972 | 0.13 |

`cpu` preset, seeds 0 1 2, 150 steps/phase (`runs/cpu_3seeds/`, ~33 s total):

| mode | avg online loss | avg online acc | forget gap (loss) | forget gap (acc) | relearn first-k loss | ms/step |
|---|---|---|---|---|---|---|
| frozen | 7.214 ± 0.100 | 0.021 | 0.000 | 0.000 | 7.373 | 2.7 |
| bptt | **0.443 ± 0.010** | **0.914** | 6.962 ± 0.202 | 0.970 | 1.981 | 7.5 |
| hebbian | 0.824 ± 0.004 | 0.809 | 7.610 ± 0.142 | 0.970 | 4.182 | 3.3 |
| local_head | 1.686 ± 0.010 | 0.551 | 2.100 ± 0.046 | 0.970 | 1.954 | 3.0 |

How to read this (honestly):
* The local adapter recovers most of the BPTT online accuracy (0.81 vs 0.91) at
  ~2.3× lower per-step cost, without a backward pass. BPTT still wins on loss.
* **Both forget A almost completely** after B (acc gap ≈ 0.97). The fast memory buys
  plasticity, not stability; its λ damping and the shared head make it overwrite.
  Lower loss-gap for `local_head` just reflects it being less confident, not retention.
* The task is easy for a linear readout once the backbone's pretraining on P has
  taught it to carry the previous token, which flatters the head-only methods.
  Seed std is small partly because the task maps are fixed across seeds (only
  init/batches vary). None of this transfers to the language-model gap in [B] §7.2.

## Layout

```
continual/
  README.md  requirements.txt
  continual/
    __init__.py
    config.py          ContinualConfig + presets smoke / cpu / long
    hebbian_update.py  delta/eligibility rule (head) + Oja rule (fast memory)
    adapter.py         AdaptedBDH: unchanged BDH + head W,b + fast memory M
    tasks.py           KVTask (permutation maps, lag) + TaskStream (phases, eval sets)
    train_compare.py   runs modes, writes metrics.json + comparison.md
    smoke_test.py      unit checks of the rules + tiny CPU run, exits 0
  runs/
```

## Run

```bash
cd /workspace/bdh-research/continual
PY=/workspace/bdh-research/.venv/bin/python
$PY continual/smoke_test.py                                   # ~2 s, runs/smoke/
$PY -m continual.train_compare --preset cpu --seeds 0 1 2     # ~30 s
$PY -m continual.train_compare --preset cpu --seeds 0 1 2 --modes frozen bptt hebbian local_head
$PY -m continual.train_compare --preset long --seeds 0 1 2    # 3-layer BDH, A→B→A→B, ~10-20 min/seed on CPU
# knobs: --steps-per-phase N --pretrain-steps N --trace-gamma 0.5 --out runs/NAME
```

## Next steps (not done)

Stability for the fast path (task-gated or consolidating memory, slower λ, replay-free
EWC-like local terms); harder streams where the lag/context must be re-learned (so the
backbone itself must adapt); local rules on BDH's own σ/ρ instead of a readout; a
real LM stream to approach the §7.2 setting.

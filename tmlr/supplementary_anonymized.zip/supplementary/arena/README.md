# Architecture Arena — Phase 2

**ALRS → Arena → Continual Adapter.** Phase 1 (`../alrs`) built an inference-time
Hebbian-memory learner. Phase 2 is an automatic experiment harness that trains
matched-scale byte-level LMs under one config, same seed, same data stream and same
step budget, then writes a leaderboard of which architecture wins. Phase 3
(Continual Adapter) will reuse this harness to compare architectures under
sequential / continual-learning tasks.

## Contestants

| key | model | source |
|---|---|---|
| `bdh` | Pathway BDH (Kosowski et al., arXiv:2509.26507) | `../code/bdh/bdh.py`, **imported unchanged** through `arena/models/bdh_wrap.py` |
| `transformer` | Tiny GPT: pre-LN, causal softmax MHA (`F.scaled_dot_product_attention`), GELU FFN, learned positions | `arena/models/transformer.py` (ours) |
| `linear_attn` | **Linear-attention baseline**: same shell as the Transformer, but the mixer is non-softmax kernel attention `φ(q)·Σφ(k)vᵀ / φ(q)·Σφ(k)` with `φ = elu+1` | `arena/models/linear_attn.py` (ours) |

`linear_attn` uses the causal kernel form popularised by Katharopoulos et al. 2020,
but it is **only a matched-scale baseline**, not a reproduction of that paper. There
are no custom CUDA kernels and none of its experiments. By default it is evaluated in
the O(T²) masked form; the prefix-sum (linear-time/recurrent) form gives the same
output, and `smoke_test.py` asserts that the two match.

## Layout

```
arena/
  README.md  requirements.txt
  arena/
    config.py          ArenaConfig + presets smoke / cpu / full
    models/            transformer.py  linear_attn.py  bdh_wrap.py  __init__.py (registry, param formulas)
    data.py            tiny-shakespeare bytes (BDH train.py URL + 90/10 split) | synthetic recall
    train_one.py       train one arch → runs/<dir>/<arch>.json (loss curve, evals, params, wall time)
    run_arena.py       all archs → leaderboard.json + leaderboard.md
    smoke_test.py      few-step CPU run of all three; exits 0
  data/input.txt       cached tiny-shakespeare (fetched on first use)
  runs/
```

## How to run

```bash
cd /workspace/bdh-research/arena
PY=/workspace/bdh-research/.venv/bin/python

$PY -m arena.smoke_test                         # ~3 s on CPU, writes runs/smoke-{shakespeare,recall}/
$PY -m arena.run_arena                          # short CPU default: preset "cpu", 300 steps (~5.3 min on 8 CPU cores; BDH is ~90% of it)
$PY -m arena.run_arena --task recall            # synthetic multi-query associative recall
$PY -m arena.run_arena --steps 500              # any field can be overridden: --seed --device --threads
$PY -m arena.run_arena --match-params           # widen TF/LA FFN so params ≈ BDH
$PY -m arena.run_arena --full --device cuda     # BDHConfig defaults + BDH train.py recipe, 3000 steps
$PY -m arena.train_one --arch bdh --preset cpu  # a single contestant
```

Each run directory holds `<arch>.json` (config, per-step train loss, eval curve,
params, wall time, tokens/s) and `leaderboard.json` / `leaderboard.md`. Leaderboard
fields: `rank, architecture, params, best_val_loss, final_val_loss, final_val_acc,
train_time_s, steps, seed, task`. They are ranked by `best_val_loss` (lower is better).

### Presets (`arena/config.py`)

| preset | L | D | H | BDH mult (n = D·mult) | block | batch | steps | eval every / iters |
|---|---|---|---|---|---|---|---|---|
| smoke | 2 | 64 | 4 | 16 (n=1024) | 64 | 8 | 20 | 10 / 2 |
| cpu (default) | 4 | 128 | 4 | 32 (n=4096) | 128 | 16 | 300 | 50 / 10 |
| full | 6 | 256 | 4 | 128 (n=32768) — `BDHConfig()` defaults | 512 | 32 | 3000 | 250 / 50 |

Shared across all archs: vocab 256 (bytes), dropout 0.1, AdamW lr 1e-3, wd 0.1 (as
in BDH `train.py`), 5% linear warmup then cosine decay to 10%, grad-clip 1.0, fp32,
and no `torch.compile`.

### Tasks
* `shakespeare`: next-byte LM on tiny-shakespeare (same URL and 90/10 split as
  `code/bdh/train.py`). `final_val_acc` = next-byte top-1.
* `recall`: each sequence = P distinct (key,value) pairs (keys from 128 byte tokens,
  values from 64), then a separator, then Q queries `key value`. Loss and accuracy
  count **only** the queried values (other targets = −100). Chance ≈ 1/64 ≈ 0.016,
  loss ≈ ln 64 ≈ 4.16 once the value alphabet is learned.

## Fairness caveats (read before quoting a winner)

1. **The param counts don't match by default.** The default matches *dims* (same L, D, H,
   vocab). BDH's parameters are `3·n·D + 2·V·D` with `n = D·mlp_mult`, and they are
   **shared across layers**. The Transformer/linear-attn have `L·(4D² + 2·h·D)` + embeddings.
   With `--match-params`, the FFN width `h` is solved so that params match:

   | preset | BDH | TF / LA (dims-matched, ffn×4) | TF / LA with `--match-params` (ffn mult) |
   |---|---|---|---|
   | smoke | 229,376 | 135,808 | 229,504 (×9.71) |
   | cpu | 1,638,400 | 870,656 | 1,638,656 (×9.86) |
   | full | 25,296,896 | 4,987,392 | 25,296,384 (×29.82) |

   Even then, the compute isn't matched. BDH runs its shared weights L times over an
   n-wide (n ≫ D) sparse layer, so it uses much more FLOPs/step and wall time per step.
   The arena uses the same *step and token* budget, not the same FLOPs or wall time.
   Compare `train_time_s` / `tokens_per_s` too.
2. **Positions differ.** BDH uses its own RoPE-style phases. TF/LA use learned absolute
   positions. BDH has no positional embedding params.
3. **The recipe is the same for everyone and tuned for no one.** One lr/wd/schedule
   (BDH's own lr/wd) for all archs. A per-arch sweep could reorder the board.
4. **Short CPU runs show early learning speed, not final quality.** Rankings at 20–300
   steps can change by 3000+. Use `--full` (GPU) and several `--seed`s before drawing
   conclusions.
5. **The noise is small but real.** The seed fixes init RNG, the training batch stream
   (identical across archs) and the eval batches. CPU fp32 is deterministic enough for
   reruns, but there is no multi-seed CI yet.
6. **BDH is unchanged.** We wrap `bdh.BDH` and only recompute the loss with explicit
   `ignore_index=-100`, which is BDH's own default. Its dropout, LayerNorm placement and
   init are Pathway's.

## Sample results (this box, 8 CPU cores, seed 1337, 2026-10-27)

`smoke` (20 steps, shakespeare). These only prove that the pipeline works:

| architecture | params | best_val_loss | train_time_s |
|---|---|---|---|
| transformer | 135,808 | 4.4055 | 0.1 |
| linear_attn | 135,808 | 4.4059 | 0.1 |
| bdh | 229,376 | 4.4592 | 0.3 |

`cpu` default (300 steps, shakespeare, dims-matched), in `runs/arena-shakespeare-cpu-default/`:

| architecture | params | best_val_loss | final_val_acc | train_time_s |
|---|---|---|---|---|
| bdh | 1,638,400 | 1.8753 | 0.457 | 274.1 |
| linear_attn | 870,656 | 2.4329 | 0.288 | 19.7 |
| transformer | 870,656 | 2.4418 | 0.285 | 22.6 |

BDH wins per step, but it has about 1.9× the params and took about 12× the wall time.
At equal wall time the picture may differ (caveat 1). The TF/LA baselines are still
on their early bigram plateau at 300 steps.

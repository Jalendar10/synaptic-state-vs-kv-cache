# Arena leaderboard — task `shakespeare`, preset `smoke`

Winner: **transformer** · seed 1337 · 20 steps · L=2 D=64 H=4 block=64 batch=8 · BDH n=1024 · match_params=False

| rank | architecture | params | best_val_loss | final_val_loss | final_val_acc (next-byte top-1) | train_time_s | steps | seed | task |
|---|---|---|---|---|---|---|---|---|---|
| 1 | transformer | 135,808 | 4.4055 | 4.4055 | 0.148 | 0.1 | 20 | 1337 | shakespeare |
| 2 | linear_attn | 135,808 | 4.4059 | 4.4059 | 0.148 | 0.1 | 20 | 1337 | shakespeare |
| 3 | bdh | 229,376 | 4.4592 | 4.4592 | 0.210 | 0.3 | 20 | 1337 | shakespeare |

Labels:
- `transformer`: Tiny Transformer (causal softmax MHA + GELU FFN)
- `linear_attn`: Linear-attention BASELINE (elu+1 kernel, no softmax)
- `bdh`: BDH (Pathway bdh.py, unchanged)

# Arena leaderboard — task `recall`, preset `smoke`

Winner: **linear_attn** · seed 1337 · 20 steps · L=2 D=64 H=4 block=64 batch=8 · BDH n=1024 · match_params=False

| rank | architecture | params | best_val_loss | final_val_loss | final_val_acc (masked recall accuracy) | train_time_s | steps | seed | task |
|---|---|---|---|---|---|---|---|---|---|
| 1 | linear_attn | 135,808 | 4.9306 | 4.9306 | 0.017 | 0.1 | 20 | 1337 | recall |
| 2 | transformer | 135,808 | 4.9404 | 4.9404 | 0.017 | 0.1 | 20 | 1337 | recall |
| 3 | bdh | 229,376 | 5.0182 | 5.0182 | 0.021 | 0.3 | 20 | 1337 | recall |

Labels:
- `linear_attn`: Linear-attention BASELINE (elu+1 kernel, no softmax)
- `transformer`: Tiny Transformer (causal softmax MHA + GELU FFN)
- `bdh`: BDH (Pathway bdh.py, unchanged)

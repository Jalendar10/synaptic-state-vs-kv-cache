# Arena leaderboard — task `shakespeare`, preset `cpu`

Winner: **bdh** · seed 1337 · 300 steps · L=4 D=128 H=4 block=128 batch=16 · BDH n=4096 · match_params=False

| rank | architecture | params | best_val_loss | final_val_loss | final_val_acc (next-byte top-1) | train_time_s | steps | seed | task |
|---|---|---|---|---|---|---|---|---|---|
| 1 | bdh | 1,638,400 | 1.8753 | 1.8753 | 0.457 | 274.1 | 300 | 1337 | shakespeare |
| 2 | linear_attn | 870,656 | 2.4329 | 2.4329 | 0.288 | 19.7 | 300 | 1337 | shakespeare |
| 3 | transformer | 870,656 | 2.4418 | 2.4418 | 0.285 | 22.6 | 300 | 1337 | shakespeare |

Labels:
- `bdh`: BDH (Pathway bdh.py, unchanged)
- `linear_attn`: Linear-attention BASELINE (elu+1 kernel, no softmax)
- `transformer`: Tiny Transformer (causal softmax MHA + GELU FFN)

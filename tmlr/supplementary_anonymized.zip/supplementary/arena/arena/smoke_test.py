"""Tiny CPU run: all three architectures, few steps, mini leaderboard. Exits 0 on success.

python -m arena.smoke_test
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from arena.config import preset
from arena.models.linear_attn import CausalLinearAttention
from arena.run_arena import run_arena
from arena.train_one import RUNS
from arena import models


def check_linear_attn_equivalence():
    torch.manual_seed(0)
    m = CausalLinearAttention(32, 4, 0.0).eval()
    x = torch.randn(2, 17, 32)
    CausalLinearAttention.mode = "quadratic"; a = m(x)
    CausalLinearAttention.mode = "prefix"; b = m(x)
    CausalLinearAttention.mode = "quadratic"
    assert torch.allclose(a, b, atol=1e-5), (a - b).abs().max()


def check_param_formulas():
    cfg = preset("smoke")
    for arch, f in (("bdh", models.bdh_param_count), ("transformer", models.tinylm_param_count)):
        assert models.count_params(models.build(arch, cfg)) == f(cfg), arch


def main():
    torch.set_num_threads(min(4, torch.get_num_threads()))
    check_linear_attn_equivalence()
    check_param_formulas()
    try:
        from arena.data import fetch_shakespeare
        fetch_shakespeare()
        task = "shakespeare"
    except Exception as e:  # offline box
        print(f"tiny-shakespeare unavailable ({e}); smoke on recall task", file=sys.stderr)
        task = "recall"
    ok = True
    for t in dict.fromkeys([task, "recall"]):
        rows, out = run_arena("smoke", out_dir=RUNS / f"smoke-{t}", task=t, verbose=False)
        print((out / "leaderboard.md").read_text())
        for r in rows:
            ok &= r["best_val_loss"] == r["best_val_loss"] and r["best_val_loss"] < 10  # finite
        ok &= {r["architecture"] for r in rows} == set(models.ARCHS)
        json.loads((out / "leaderboard.json").read_text())
    print("SMOKE OK" if ok else "SMOKE FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

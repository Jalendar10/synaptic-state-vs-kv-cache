"""Train + evaluate ONE architecture under an ArenaConfig.

python -m arena.train_one --arch transformer --preset cpu --task shakespeare
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from arena.config import PRESETS, ArenaConfig, preset
from arena.data import make_data
from arena import models

RUNS = Path(__file__).resolve().parents[1] / "runs"


@torch.no_grad()
def evaluate(model, data, cfg, split="val"):
    model.eval()
    gen = torch.Generator().manual_seed(cfg.seed + (1 if split == "val" else 2))
    tot_loss, correct, count = 0.0, 0, 0
    for _ in range(cfg.eval_iters):
        x, y = data.get_batch(split, gen)
        x, y = x.to(cfg.device), y.to(cfg.device)
        logits, loss = model(x, y)
        tot_loss += loss.item()
        m = y != -100
        correct += (logits.argmax(-1)[m] == y[m]).sum().item()
        count += m.sum().item()
    model.train()
    return tot_loss / cfg.eval_iters, correct / max(count, 1)


def train_one(arch: str, cfg: ArenaConfig, out_dir: Path | None = None, verbose=True, data=None):
    if cfg.threads:
        torch.set_num_threads(cfg.threads)
    if arch != "bdh" and cfg.match_params:
        cfg = cfg.replace(ffn_mult=models.matched_ffn_mult(cfg))
    data = data or make_data(cfg)
    torch.manual_seed(cfg.seed)                       # same init seed for every arch
    model = models.build(arch, cfg).to(cfg.device)
    n_params = models.count_params(model)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    warmup = max(1, cfg.steps // 20)
    def lr_lambda(s):  # linear warmup, then cosine decay to 10% of lr
        if s < warmup:
            return (s + 1) / warmup
        prog = min(1.0, (s - warmup) / max(1, cfg.steps - warmup))
        return 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * prog))
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda)
    train_gen = torch.Generator().manual_seed(cfg.seed)  # same batch stream for every arch
    curve, evals = [], []
    best = (float("inf"), None, 0.0)
    if verbose:
        print(f"[{arch}] params={n_params:,} task={cfg.task} steps={cfg.steps}", flush=True)
    t0 = time.perf_counter()
    for step in range(1, cfg.steps + 1):
        x, y = data.get_batch("train", train_gen)
        _, loss = model(x.to(cfg.device), y.to(cfg.device))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        if cfg.grad_clip:
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        opt.step()
        sched.step()
        curve.append(round(loss.item(), 5))
        if step % cfg.eval_every == 0 or step == cfg.steps:
            vl, acc = evaluate(model, data, cfg)
            evals.append({"step": step, "val_loss": round(vl, 5), "val_acc": round(acc, 5),
                          "elapsed_s": round(time.perf_counter() - t0, 2)})
            if vl < best[0]:
                best = (vl, step, acc)
            if verbose:
                print(f"[{arch}] step {step:5d} train {curve[-1]:.4f} val {vl:.4f}"
                      f" acc {acc:.3f} ({time.perf_counter() - t0:.1f}s)", flush=True)
    train_time = time.perf_counter() - t0
    tokens = cfg.steps * cfg.batch_size * cfg.block_size
    result = {
        "architecture": arch,
        "label": models.LABELS[arch],
        "params": n_params,
        "best_val_loss": round(best[0], 5),
        "best_step": best[1],
        "final_val_loss": evals[-1]["val_loss"],
        "best_val_acc_at_best": round(best[2], 5),
        "final_val_acc": evals[-1]["val_acc"],
        "train_time_s": round(train_time, 2),
        "tokens_per_s": round(tokens / train_time, 1),
        "steps": cfg.steps,
        "seed": cfg.seed,
        "task": cfg.task,
        "config": cfg.to_dict(),
        "eval_curve": evals,
        "train_loss_curve": curve,
    }
    if arch == "bdh":
        result["bdh_neurons_n"] = cfg.n_embd * cfg.bdh_mlp_mult
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / f"{arch}.json").write_text(json.dumps(result, indent=1))
    return result


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--arch", required=True, choices=models.ARCHS)
    ap.add_argument("--preset", default="cpu", choices=list(PRESETS))
    ap.add_argument("--task", choices=["shakespeare", "recall"])
    ap.add_argument("--steps", type=int)
    ap.add_argument("--seed", type=int)
    ap.add_argument("--device")
    ap.add_argument("--match-params", action="store_true")
    ap.add_argument("--out", type=Path)
    a = ap.parse_args(argv)
    cfg = preset(a.preset, task=a.task, steps=a.steps, seed=a.seed, device=a.device,
                 match_params=a.match_params or None)
    out = a.out or RUNS / f"single-{a.arch}-{cfg.task}-{time.strftime('%Y%m%d-%H%M%S')}"
    r = train_one(a.arch, cfg, out)
    print(json.dumps({k: r[k] for k in ("architecture", "params", "best_val_loss",
                                         "final_val_acc", "train_time_s")}))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()

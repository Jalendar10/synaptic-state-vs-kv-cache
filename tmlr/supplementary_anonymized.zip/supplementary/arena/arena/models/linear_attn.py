"""Linear-attention BASELINE (kernelised, no softmax).

Token mixer:  y_t = sum_{s<=t} phi(q_t).phi(k_s) v_s / (sum_{s<=t} phi(q_t).phi(k_s) + eps)
with phi(x) = elu(x) + 1 (positive feature map).  This is the causal
kernelised-attention form popularised by Katharopoulos et al. 2020, but this
file is only a matched-scale *baseline* for the arena: we do not reproduce
their experiments, kernels, or their O(T) recurrent CUDA implementation.

Two mathematically equivalent evaluation modes:
  * "quadratic": masked (phi(Q) phi(K)^T) V   -- O(T^2), low memory, default
  * "prefix":    cumulative sums of phi(k) v^T -- O(T d^2) memory, the true
                 linear-time/recurrent form (useful to verify equivalence)
Everything else (pre-LN blocks, GELU FFN, learned positions, head) is shared
with the tiny Transformer so only the token mixer differs.
"""
import torch
import torch.nn.functional as F
from torch import nn

from .transformer import TinyLM


def phi(x):
    return F.elu(x) + 1.0


class CausalLinearAttention(nn.Module):
    mode = "quadratic"

    def __init__(self, d, nh, dropout, eps=1e-6):
        super().__init__()
        assert d % nh == 0
        self.nh, self.eps = nh, eps
        self.qkv = nn.Linear(d, 3 * d, bias=False)
        self.proj = nn.Linear(d, d, bias=False)
        self.resid_drop = nn.Dropout(dropout)

    def forward(self, x):
        B, T, D = x.shape
        q, k, v = self.qkv(x).split(D, dim=2)
        q, k, v = (t.view(B, T, self.nh, D // self.nh).transpose(1, 2) for t in (q, k, v))
        q, k = phi(q), phi(k)
        if self.mode == "prefix":
            kv = torch.cumsum(k.unsqueeze(-1) * v.unsqueeze(-2), dim=2)   # B,H,T,dk,dv
            z = torch.cumsum(k, dim=2)                                     # B,H,T,dk
            num = torch.einsum("bhtd,bhtde->bhte", q, kv)
            den = (q * z).sum(-1, keepdim=True)
        else:
            a = (q @ k.transpose(-1, -2)).tril()                           # B,H,T,T (>=0)
            num = a @ v
            den = a.sum(-1, keepdim=True)
        y = num / (den + self.eps)
        y = y.transpose(1, 2).reshape(B, T, D)
        return self.resid_drop(self.proj(y))


def LinearAttentionLM(cfg):
    return TinyLM(cfg, CausalLinearAttention)

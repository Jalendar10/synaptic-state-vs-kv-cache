"""Thin wrapper: imports Pathway's BDH *unchanged* from ../code/bdh/bdh.py.

Override the location with  ARENA_BDH_PATH=/path/to/dir/containing/bdh.py
"""
import os
import sys
from pathlib import Path

import torch.nn.functional as F
from torch import nn

_BDH_DIR = Path(os.environ.get(
    "ARENA_BDH_PATH", Path(__file__).resolve().parents[3] / "code" / "bdh"))
if str(_BDH_DIR) not in sys.path:
    sys.path.insert(0, str(_BDH_DIR))

import bdh as pathway_bdh  # noqa: E402


def bdh_config(cfg):
    return pathway_bdh.BDHConfig(
        n_layer=cfg.n_layer, n_embd=cfg.n_embd, dropout=cfg.dropout, n_head=cfg.n_head,
        mlp_internal_dim_multiplier=cfg.bdh_mlp_mult, vocab_size=cfg.vocab_size)


class BDHWrap(nn.Module):
    """Same (idx, targets) -> (logits, loss) contract as the other models.

    BDH's own loss uses F.cross_entropy default ignore_index=-100, which the
    recall task relies on; we recompute it here anyway to be explicit.
    """

    def __init__(self, cfg):
        super().__init__()
        self.bdh_config = bdh_config(cfg)
        self.model = pathway_bdh.BDH(self.bdh_config)

    def forward(self, idx, targets=None):
        logits, _ = self.model(idx)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1),
                                   ignore_index=-100)
        return logits, loss


def bdh_neurons(cfg):
    return cfg.n_embd * cfg.bdh_mlp_mult  # n = nh * N

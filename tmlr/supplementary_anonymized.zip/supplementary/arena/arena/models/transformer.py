"""Tiny GPT-style Transformer: pre-LN, causal softmax multi-head attention + GELU FFN."""
import math

import torch
import torch.nn.functional as F
from torch import nn


class CausalSelfAttention(nn.Module):
    def __init__(self, d, nh, dropout):
        super().__init__()
        assert d % nh == 0
        self.nh = nh
        self.qkv = nn.Linear(d, 3 * d, bias=False)
        self.proj = nn.Linear(d, d, bias=False)
        self.dropout = dropout
        self.resid_drop = nn.Dropout(dropout)

    def forward(self, x):
        B, T, D = x.shape
        q, k, v = self.qkv(x).split(D, dim=2)
        q, k, v = (t.view(B, T, self.nh, D // self.nh).transpose(1, 2) for t in (q, k, v))
        y = F.scaled_dot_product_attention(
            q, k, v, is_causal=True, dropout_p=self.dropout if self.training else 0.0)
        y = y.transpose(1, 2).reshape(B, T, D)
        return self.resid_drop(self.proj(y))


class FFN(nn.Module):
    def __init__(self, d, hidden, dropout):
        super().__init__()
        self.fc = nn.Linear(d, hidden, bias=False)
        self.out = nn.Linear(hidden, d, bias=False)
        self.drop = nn.Dropout(dropout)

    def forward(self, x):
        return self.drop(self.out(F.gelu(self.fc(x))))


class Block(nn.Module):
    def __init__(self, d, nh, hidden, dropout, attn_cls):
        super().__init__()
        self.ln1 = nn.LayerNorm(d)
        self.attn = attn_cls(d, nh, dropout)
        self.ln2 = nn.LayerNorm(d)
        self.ffn = FFN(d, hidden, dropout)

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        return x + self.ffn(self.ln2(x))


class TinyLM(nn.Module):
    """Shared LM shell; `attn_cls` decides the token mixer."""

    def __init__(self, cfg, attn_cls=CausalSelfAttention):
        super().__init__()
        d = cfg.n_embd
        hidden = int(round(cfg.ffn_mult * d))
        self.tok = nn.Embedding(cfg.vocab_size, d)
        self.pos = nn.Embedding(cfg.block_size, d)
        self.drop = nn.Dropout(cfg.dropout)
        self.blocks = nn.ModuleList(
            [Block(d, cfg.n_head, hidden, cfg.dropout, attn_cls) for _ in range(cfg.n_layer)])
        self.ln_f = nn.LayerNorm(d)
        self.head = nn.Linear(d, cfg.vocab_size, bias=False)
        self.apply(self._init)
        for n, p in self.named_parameters():
            if n.endswith("proj.weight") or n.endswith("out.weight"):
                nn.init.normal_(p, std=0.02 / math.sqrt(2 * cfg.n_layer))

    @staticmethod
    def _init(m):
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, std=0.02)

    def forward(self, idx, targets=None):
        B, T = idx.shape
        pos = torch.arange(T, device=idx.device)
        x = self.drop(self.tok(idx) + self.pos(pos))
        for b in self.blocks:
            x = b(x)
        logits = self.head(self.ln_f(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1),
                                   ignore_index=-100)
        return logits, loss


def TinyTransformer(cfg):
    return TinyLM(cfg, CausalSelfAttention)

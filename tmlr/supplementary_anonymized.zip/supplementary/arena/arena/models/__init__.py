"""Model registry + parameter accounting for the arena."""
from .transformer import TinyTransformer
from .linear_attn import LinearAttentionLM

ARCHS = ("bdh", "transformer", "linear_attn")

LABELS = {
    "bdh": "BDH (Pathway bdh.py, unchanged)",
    "transformer": "Tiny Transformer (causal softmax MHA + GELU FFN)",
    "linear_attn": "Linear-attention BASELINE (elu+1 kernel, no softmax)",
}


def build(arch, cfg):
    if arch == "bdh":
        from .bdh_wrap import BDHWrap
        return BDHWrap(cfg)
    if arch == "transformer":
        return TinyTransformer(cfg)
    if arch == "linear_attn":
        return LinearAttentionLM(cfg)
    raise ValueError(f"unknown arch {arch!r}; choose from {ARCHS}")


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def bdh_param_count(cfg):
    D, V = cfg.n_embd, cfg.vocab_size
    n = D * cfg.bdh_mlp_mult            # nh * N
    return 3 * n * D + 2 * V * D        # encoder, encoder_v, decoder, embed, lm_head


def tinylm_param_count(cfg, ffn_mult=None):
    D, V, L = cfg.n_embd, cfg.vocab_size, cfg.n_layer
    h = int(round((cfg.ffn_mult if ffn_mult is None else ffn_mult) * D))
    per_layer = 4 * D * D + 2 * h * D + 4 * D        # qkv+proj, ffn, 2 LayerNorms
    return V * D + cfg.block_size * D + L * per_layer + 2 * D + D * V


def matched_ffn_mult(cfg):
    """ffn_mult such that TinyLM params ~= BDH params (same L, D, heads)."""
    D, L = cfg.n_embd, cfg.n_layer
    target = bdh_param_count(cfg)
    fixed = tinylm_param_count(cfg, ffn_mult=0)
    h = max(1.0, (target - fixed) / (2 * D * L))
    return h / D

"""Byte-level data for the arena.

* shakespeare: tiny-shakespeare as raw bytes (same file + 90/10 split as
  Pathway's code/bdh/train.py), vocab 256.
* recall: synthetic multi-query associative recall in byte vocab.
  Sequence = P (key,value) pairs | SEP | Q queries "key value"; loss and
  accuracy only on the queried values (other targets = -100).
"""
from __future__ import annotations

import os
import urllib.request
from pathlib import Path

import numpy as np
import torch

URL = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"
DATA_DIR = Path(os.environ.get("ARENA_DATA_DIR", Path(__file__).resolve().parents[1] / "data"))
_BDH_INPUT = Path(__file__).resolve().parents[2] / "code" / "bdh" / "input.txt"

KEY_LO, KEY_HI = 128, 256     # 128 key tokens
VAL_LO, VAL_HI = 32, 96       # 64 value tokens
SEP = 10


def fetch_shakespeare() -> Path:
    for p in (DATA_DIR / "input.txt", _BDH_INPUT):
        if p.exists() and p.stat().st_size > 100_000:
            return p
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    dst = DATA_DIR / "input.txt"
    with urllib.request.urlopen(URL, timeout=30) as r:
        dst.write_bytes(r.read())
    return dst


class ShakespeareData:
    task = "shakespeare"

    def __init__(self, cfg):
        raw = np.frombuffer(fetch_shakespeare().read_bytes(), dtype=np.uint8)
        cut = int(0.9 * len(raw))
        self.splits = {"train": torch.from_numpy(raw[:cut].astype(np.int64)),
                       "val": torch.from_numpy(raw[cut:].astype(np.int64))}
        self.T, self.B = cfg.block_size, cfg.batch_size

    def get_batch(self, split, gen: torch.Generator):
        d = self.splits[split]
        ix = torch.randint(len(d) - self.T - 1, (self.B,), generator=gen)
        x = torch.stack([d[i:i + self.T] for i in ix.tolist()])
        y = torch.stack([d[i + 1:i + 1 + self.T] for i in ix.tolist()])
        return x, y


class RecallData:
    task = "recall"

    def __init__(self, cfg):
        self.T, self.B = cfg.block_size, cfg.batch_size
        self.P = min(KEY_HI - KEY_LO, (self.T - 1) // 4)
        self.Q = min(self.P, (self.T - 1 - 2 * self.P) // 2)
        assert self.P >= 2 and self.Q >= 1, "block_size too small for recall task"

    def get_batch(self, split, gen: torch.Generator):
        # split only changes the RNG stream (train/val generators are seeded differently)
        B, T, P, Q = self.B, self.T, self.P, self.Q
        seq = torch.full((B, T + 1), SEP, dtype=torch.long)
        tgt = torch.full((B, T + 1), -100, dtype=torch.long)
        for b in range(B):
            keys = torch.randperm(KEY_HI - KEY_LO, generator=gen)[:P] + KEY_LO
            vals = torch.randint(VAL_LO, VAL_HI, (P,), generator=gen)
            seq[b, 0:2 * P:2], seq[b, 1:2 * P:2] = keys, vals
            q = torch.randint(0, P, (Q,), generator=gen)
            start = 2 * P + 1
            seq[b, start:start + 2 * Q:2] = keys[q]
            seq[b, start + 1:start + 2 * Q:2] = vals[q]
            tgt[b, start + 1:start + 2 * Q:2] = vals[q]
        return seq[:, :-1].contiguous(), tgt[:, 1:].contiguous()


def make_data(cfg):
    if cfg.task == "shakespeare":
        return ShakespeareData(cfg)
    if cfg.task == "recall":
        return RecallData(cfg)
    raise ValueError(f"unknown task {cfg.task!r}")

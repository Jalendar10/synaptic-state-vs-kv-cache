"""Architecture Arena (Phase 2 of ALRS -> Arena -> Continual).

Trains BDH (Pathway, imported unchanged), a tiny softmax Transformer and a
kernelised linear-attention baseline under one shared config and logs which
one wins.
"""
__version__ = "0.1.0"

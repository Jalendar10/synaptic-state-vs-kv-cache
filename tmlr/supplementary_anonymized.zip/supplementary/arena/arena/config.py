"""Shared train config for every architecture in the arena."""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, asdict


@dataclass
class ArenaConfig:
    # model dims (shared by all three; BDH-specific knob below)
    vocab_size: int = 256          # bytes
    n_layer: int = 4
    n_embd: int = 128
    n_head: int = 4
    dropout: float = 0.1
    bdh_mlp_mult: int = 32         # BDHConfig.mlp_internal_dim_multiplier
    ffn_mult: float = 4.0          # Transformer / linear-attn FFN hidden = ffn_mult * n_embd
    match_params: bool = False     # if True, ffn_mult is solved so TF/LA params ~= BDH params
    # data / optimisation
    task: str = "shakespeare"      # "shakespeare" | "recall"
    block_size: int = 128
    batch_size: int = 16
    steps: int = 300
    lr: float = 1e-3
    weight_decay: float = 0.1
    grad_clip: float = 1.0
    eval_every: int = 50
    eval_iters: int = 10
    seed: int = 1337
    device: str = "cpu"
    threads: int = 0               # 0 = torch default

    def to_dict(self):
        return asdict(self)

    def replace(self, **kw):
        return dataclasses.replace(self, **{k: v for k, v in kw.items() if v is not None})


PRESETS = {
    # few-step CPU sanity run
    "smoke": dict(n_layer=2, n_embd=64, n_head=4, bdh_mlp_mult=16, block_size=64,
                  batch_size=8, steps=20, eval_every=10, eval_iters=2),
    # default short CPU arena (~minutes)
    "cpu": dict(),
    # BDHConfig defaults + BDH train.py recipe (GPU recommended)
    "full": dict(n_layer=6, n_embd=256, n_head=4, bdh_mlp_mult=128, block_size=512,
                 batch_size=32, steps=3000, eval_every=250, eval_iters=50),
}


def preset(name: str, **overrides) -> ArenaConfig:
    return ArenaConfig(**PRESETS[name]).replace(**overrides)

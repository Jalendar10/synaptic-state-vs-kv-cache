"""Run all architectures with the same seed / data stream / steps and write a leaderboard.

python -m arena.run_arena                     # short CPU default (preset "cpu", 300 steps)
python -m arena.run_arena --task recall       # synthetic associative recall
python -m arena.run_arena --full              # BDHConfig defaults, 3000 steps (GPU recommended)
python -m arena.run_arena --match-params      # widen TF/LA FFN so params ~= BDH
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from arena.config import PRESETS, preset
from arena.data import make_data
from arena.train_one import RUNS, train_one
from arena import models

FIELDS = ("architecture", "params", "best_val_loss", "final_val_loss", "final_val_acc",
          "train_time_s", "steps", "seed", "task")


def write_leaderboard(results, cfg, out_dir: Path, preset_name: str):
    board = sorted(results, key=lambda r: r["best_val_loss"])
    rows = [{"rank": i + 1, **{k: r[k] for k in FIELDS}} for i, r in enumerate(board)]
    meta = {"preset": preset_name, "created": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
            "winner": rows[0]["architecture"], "metric": "best_val_loss (lower is better)",
            "config": cfg.to_dict(), "labels": {r["architecture"]: r["label"] for r in board}}
    (out_dir / "leaderboard.json").write_text(json.dumps({"meta": meta, "leaderboard": rows}, indent=1))
    acc_note = " (masked recall accuracy)" if cfg.task == "recall" else " (next-byte top-1)"
    md = [f"# Arena leaderboard — task `{cfg.task}`, preset `{preset_name}`", "",
          f"Winner: **{rows[0]['architecture']}** · seed {cfg.seed} · {cfg.steps} steps · "
          f"L={cfg.n_layer} D={cfg.n_embd} H={cfg.n_head} block={cfg.block_size} "
          f"batch={cfg.batch_size} · BDH n={cfg.n_embd * cfg.bdh_mlp_mult} · "
          f"match_params={cfg.match_params}", "",
          f"| rank | architecture | params | best_val_loss | final_val_loss | final_val_acc{acc_note} | train_time_s | steps | seed | task |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['rank']} | {r['architecture']} | {r['params']:,} | {r['best_val_loss']:.4f} | "
                  f"{r['final_val_loss']:.4f} | {r['final_val_acc']:.3f} | {r['train_time_s']:.1f} | "
                  f"{r['steps']} | {r['seed']} | {r['task']} |")
    md += ["", "Labels:"] + [f"- `{a}`: {l}" for a, l in meta["labels"].items()]
    (out_dir / "leaderboard.md").write_text("\n".join(md) + "\n")
    return rows


def run_arena(preset_name="cpu", archs=models.ARCHS, out_dir=None, verbose=True, **overrides):
    cfg = preset(preset_name, **overrides)
    out_dir = out_dir or RUNS / f"arena-{cfg.task}-{preset_name}-{time.strftime('%Y%m%d-%H%M%S')}"
    out_dir.mkdir(parents=True, exist_ok=True)
    data = make_data(cfg)
    results = [train_one(a, cfg, out_dir, verbose=verbose, data=data) for a in archs]
    rows = write_leaderboard(results, cfg, out_dir, preset_name)
    return rows, out_dir


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--preset", default="cpu", choices=list(PRESETS))
    ap.add_argument("--full", action="store_true", help="alias for --preset full")
    ap.add_argument("--task", choices=["shakespeare", "recall"])
    ap.add_argument("--archs", nargs="+", choices=models.ARCHS, default=list(models.ARCHS))
    ap.add_argument("--steps", type=int)
    ap.add_argument("--seed", type=int)
    ap.add_argument("--device", help="cpu | cuda | mps")
    ap.add_argument("--threads", type=int)
    ap.add_argument("--match-params", action="store_true")
    ap.add_argument("--out", type=Path)
    a = ap.parse_args(argv)
    name = "full" if a.full else a.preset
    rows, out = run_arena(name, a.archs, a.out, task=a.task, steps=a.steps, seed=a.seed,
                          device=a.device, threads=a.threads, match_params=a.match_params or None)
    print((out / "leaderboard.md").read_text())
    print(f"wrote {out}/leaderboard.json")


if __name__ == "__main__":
    main()

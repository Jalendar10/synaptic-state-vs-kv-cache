"""TinyFullConfig — one small config that switches on EVERY CDLR capability."""
from __future__ import annotations

import dataclasses
import json
from pathlib import Path


@dataclasses.dataclass
class TinyFullConfig:
    # ---- 1. sparse positive backbone -------------------------------------
    encoder: str = "bdh"          # "bdh" (Pathway bdh.py, unchanged) | "builtin"
    vocab_size: int = 16
    n_layer: int = 2              # BDH layers (<=3)
    n_embd: int = 32              # BDH d (<=64)
    n_head: int = 2
    mlp_mult: int = 8             # BDH N/head = mult*d/nh -> 2*128 = 256 neurons
    builtin_neurons: int = 256
    sparsity: float = 0.05        # k-WTA fraction
    # ---- 2. fast episodic Hebbian S --------------------------------------
    d_value: int = 32
    eta_init: float = 1.0
    decay_init: float = 0.95
    global_unit: bool = True
    # ---- 4. latent workspace ---------------------------------------------
    d_hidden: int = 32
    n_latent_steps: int = 3       # R
    early_exit: bool = True       # inference-only per-sample early exit
    exit_conf: float = 0.9        # max-softmax threshold
    # ---- slow training (episodic, backprop through demos) ----------------
    task: str = "recall"          # recall | shift | mixed (alrs.tasks)
    n_demos: int = 4
    batch_size: int = 32
    train_steps: int = 200
    lr: float = 3e-3
    # ---- continual A->B->A (frozen backbone) -----------------------------
    cont_batch: int = 32
    steps_per_phase: int = 40
    relearn_k: int = 5
    head_lr: float = 2.0          # 5. local delta/eligibility rule
    head_decay: float = 1e-4
    trace_gamma: float = 0.0
    ep_eta: float = 1.0           # episodic S for the stream (fixed, not learned)
    ep_decay: float = 0.9
    ep_alpha: float = 4.0         # read gain of S into logits
    # ---- 3. consolidated prototype bank + tiny replay ---------------------
    replay_per_slot: int = 64     # tiny reservoir buffer (tokens) per bank slot
    bank_alpha: float = 12.0      # gain of selected prototype slot
    bank_merge_sim: float = 0.8   # merge into existing slot if prototype cos-sim >= this
    bank_gate_acc: float = 0.5    # use a slot only if it explains the support batch this well
    support_size: int = 32        # support tokens used for task inference at eval
    # ---- 7. arena --------------------------------------------------------
    arena: bool = True
    # ---- misc ------------------------------------------------------------
    seed: int = 0
    threads: int = 4

    @property
    def bos_id(self):
        return self.vocab_size

    @property
    def n_features(self):
        if self.encoder == "bdh":
            return self.n_head * (self.mlp_mult * self.n_embd // self.n_head)
        return self.builtin_neurons

    def to_dict(self):
        return dataclasses.asdict(self)

    def to_json(self, path):
        Path(path).write_text(json.dumps(self.to_dict(), indent=2))

    def replace(self, **kw):
        return dataclasses.replace(self, **{k: v for k, v in kw.items() if v is not None})


PRESETS = {
    "smoke": dict(train_steps=150, steps_per_phase=25),
    "tiny": dict(),
    "long": dict(train_steps=1500, steps_per_phase=150, n_embd=64, n_layer=3, vocab_size=32,
                 n_demos=8, d_value=64, d_hidden=64, n_latent_steps=4),
}


def make_config(preset="tiny", **kw):
    return TinyFullConfig(**PRESETS[preset]).replace(**kw)

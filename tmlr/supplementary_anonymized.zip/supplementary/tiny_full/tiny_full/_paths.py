"""Make sibling research packages importable (read-only reuse, nothing copied/modified).

  ../../code/bdh   -> bdh            (Pathway bdh.py, UNCHANGED)
  ../../alrs       -> alrs           (Hebbian S, kwta, encoders, audit stats, episodic tasks)
  ../../continual  -> continual      (local delta / eligibility rules)
  ../../arena      -> arena          (tiny Transformer baseline)
"""
import os
import sys
from pathlib import Path

ROOT = Path(os.environ.get("BDH_RESEARCH_ROOT", Path(__file__).resolve().parents[2]))
for sub in ("code/bdh", "alrs", "continual", "arena"):
    p = str(ROOT / sub)
    if (ROOT / sub).is_dir() and p not in sys.path:
        sys.path.insert(0, p)

"""CPU smoke test: proves every CDLR feature in a few seconds. Exit 0 = pass.

  python -m tiny_full.smoke_test
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import torch

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tiny_full.audit import RUNS_DIR, Auditor  # noqa: E402
from tiny_full.config import make_config  # noqa: E402
from tiny_full.model import CDLR, bdh_available, param_fingerprint  # noqa: E402
from tiny_full.tasks import make_dataset  # noqa: E402
from tiny_full.train import run_all  # noqa: E402

CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": detail})
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}  {detail}")


def main():
    t0 = time.time()
    out = RUNS_DIR / "smoke"
    cfg = make_config("smoke", encoder="bdh" if bdh_available() else "builtin")
    print(f"== Tiny-Full / CDLR smoke ({cfg.encoder}, n_embd={cfg.n_embd}, n_layer={cfg.n_layer}, "
          f"neurons={cfg.n_features}, R={cfg.n_latent_steps}) ==")
    s, model, _ = run_all(cfg, out)
    inf, con, ar = s["inference"], s["continual"], s.get("arena")
    print("-- checks --")
    check("0 small default config", cfg.n_embd <= 64 and cfg.n_layer <= 3 and s["params"]["total"] < 200_000,
          f"params={s['params']['total']}")
    check("1 sparse positive backbone (Pathway BDH)", cfg.encoder == "bdh", f"features={s['n_features']}")
    check("2 memory S updated w/o weight change", inf["weights_unchanged"] and inf["S_n_writes"] == cfg.n_demos
          and inf["S_fro_norm_mean"] > 0, f"writes={inf['S_n_writes']} ||S||={inf['S_fro_norm_mean']:.2f}")
    check("2b answer lives in S (demos >> no demos)", inf["acc_with_demos"] > inf["acc_without_demos"] + 0.3,
          f"{inf['acc_with_demos']:.3f} vs {inf['acc_without_demos']:.3f}")
    check("3 consolidation ran (bank slots, merge on return)",
          [p["consolidation"]["action"] for p in con["cdlr"]["phases"]] == ["new_slot", "new_slot", "merge"])
    check("3b A->B->A forgetting logged; CDLR retains A better than Hebbian-only",
          con["cdlr_beats_hebbian_only_on_A_retention"],
          f"A@B cdlr={con['cdlr']['A_acc_after_B']:.3f} hebb={con['hebbian_only']['A_acc_after_B']:.3f}; "
          f"forget cdlr={con['cdlr']['forgetting_A_acc']:.3f} hebb={con['hebbian_only']['forgetting_A_acc']:.3f}")
    check("3c continual kept backbone/slow weights frozen", con["weights_unchanged"])
    audit = json.loads(Path(s["audit_path"]).read_text())
    ev = audit["summary"]["event_counts"]
    check("4 latent steps logged (+ early exit)", ev.get("latent_step", 0) > 0,
          f"steps_mean={inf['latent_steps_mean']:.2f}/{cfg.n_latent_steps} exit_frac={inf['early_exit_frac']:.2f}")
    check("5 local adapter steps", ev.get("adapter_step", 0) == 3 * cfg.steps_per_phase,
          f"adapter_steps={ev.get('adapter_step')}")
    check("6 audit JSON written, predict audited", Path(s["audit_path"]).exists() and ev.get("predict", 0) >= 2,
          s["audit_path"])
    check("7 arena vs tiny Transformer", ar is not None and {"cdlr", "tiny_transformer"} <= set(ar["models"]),
          " | ".join(f"{m}: acc={r['accuracy']:.3f} mem={r['memory_bytes']}B lat={r['latency_ms']:.1f}ms"
                     for m, r in (ar or {"models": {}})["models"].items()))

    # builtin backbone + full-R (no early exit): same API, R steps all logged
    cfg_b = make_config("smoke", encoder="builtin", early_exit=False)
    torch.manual_seed(0)
    mb = CDLR(cfg_b)
    aud = Auditor("smoke_builtin")
    ev_b = make_dataset("recall", 8, cfg_b.n_demos, cfg_b.vocab_size, seed=1)
    fp = param_fingerprint(mb)
    o = mb.predict(ev_b["demo_keys"], ev_b["demo_vals"], ev_b["query"], auditor=aud)
    check("1b builtin backbone selectable; full R latent steps",
          aud.counts.get("latent_step") == cfg_b.n_latent_steps and fp == param_fingerprint(mb)
          and int(o["steps_used"].min()) == cfg_b.n_latent_steps,
          f"latent_step events={aud.counts.get('latent_step')}")
    aud.save(out / "audit_builtin.json")

    ok = all(c["ok"] for c in CHECKS)
    (out / "smoke_checks.json").write_text(json.dumps({"ok": ok, "checks": CHECKS,
                                                      "wall_s": time.time() - t0}, indent=2))
    print(f"== smoke {'PASSED' if ok else 'FAILED'} in {time.time() - t0:.1f}s -> {out} ==")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

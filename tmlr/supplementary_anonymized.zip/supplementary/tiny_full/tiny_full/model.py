"""CDLR — Compact Dual-Timescale Latent Reasoner (the Tiny-Full model).

    phi(x)      sparse positive backbone: Pathway BDH (tiny, unchanged) | builtin   [1]
    S_t         fast episodic Hebbian memory, written by demos at inference      [2]
    H_0..H_R    latent workspace, R re-query steps, confidence early exit         [4]
    y_hat       G(H_R)
  online / continual side (backbone + slow weights frozen):
    logits = W phi + b                  local delta/eligibility adapter           [5]
           + a_S * read(S_stream, phi)  fast episodic S                           [2]
           + a_P * P_slot phi           slow consolidated prototype bank          [3]
  every predict() is audited                                                      [6]
"""
from __future__ import annotations

import time

import torch
import torch.nn.functional as F
from torch import nn

from . import _paths  # noqa: F401
from alrs.config import ALRSConfig
from alrs.model import (BDHFeatureEncoder, BuiltinSparseEncoder, bdh_available,  # noqa: F401
                        count_params, param_fingerprint)
from alrs.latent import kwta
from .adapter import LocalAdapter
from .audit import Auditor
from .consolidate import PrototypeBank
from .latent import LatentWorkspace
from .memory import HebbianMemory, StreamS


def _alrs_cfg(cfg):
    return ALRSConfig(vocab_size=cfg.vocab_size, encoder=cfg.encoder, bdh_n_layer=cfg.n_layer,
                      bdh_n_embd=cfg.n_embd, bdh_n_head=cfg.n_head, bdh_mlp_mult=cfg.mlp_mult,
                      builtin_n_neurons=cfg.builtin_neurons, target_sparsity=cfg.sparsity)


class CDLR(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        acfg = _alrs_cfg(cfg)
        self.encoder = BDHFeatureEncoder(acfg) if cfg.encoder == "bdh" else BuiltinSparseEncoder(acfg)
        self.n_features = self.encoder.n_out
        n = self.n_features + (1 if cfg.global_unit else 0)
        self.n_neurons = n
        V, dh, dv = cfg.vocab_size, cfg.d_hidden, cfg.d_value
        self.key_emb = nn.Embedding(V, dh)
        self.val_emb = nn.Embedding(V, dh)
        self.writer = nn.Sequential(nn.Linear(2 * dh, 2 * dh), nn.GELU(), nn.Linear(2 * dh, dv))
        self.memory = HebbianMemory(n, dv, cfg.eta_init, cfg.decay_init)
        self.enc_query = nn.Sequential(nn.Linear(dh + 2 * dv, dh), nn.GELU(), nn.Linear(dh, dh))
        self.workspace = LatentWorkspace(dh, dv, n, V, cfg.n_latent_steps, cfg.sparsity,
                                         cfg.early_exit, cfg.exit_conf)
        self.auditor = Auditor()

    # ---- [1] sparse positive features ----------------------------------
    def features(self, tokens, auditor=None, tag=""):
        raw = self.encoder(tokens)
        sp = kwta(raw, self.cfg.sparsity)
        sp = sp / sp.norm(dim=-1, keepdim=True).clamp_min(1e-6)
        if auditor is not None:
            auditor.log_encoder(tag, raw, sp)
        return sp

    def _with_global(self, sp, on):
        if not self.cfg.global_unit:
            return sp
        g = torch.full_like(sp[..., :1], 1.0 if on else 0.0)
        return torch.cat([sp, g], -1)

    # ---- [2] episodic S + [4] latent workspace --------------------------
    def forward(self, demo_keys, demo_vals, query, auditor=None):
        B, K = demo_keys.shape
        self.memory.reset(B, device=demo_keys.device)
        if K > 0:
            kf = self._with_global(self.features(demo_keys, auditor, "demo_keys"), on=True)
            vals = self.writer(torch.cat([self.key_emb(demo_keys), self.val_emb(demo_vals)], -1))
        for t in range(K):
            self.memory.update(kf[:, t], vals[:, t])           # state only, no params
            if auditor is not None:
                auditor.log_update(t, kf[:, t], vals[:, t], self.memory)
        q = self._with_global(self.features(query, auditor, "query"), on=False)
        r_direct = self.memory.read(q)
        e = torch.zeros(B, self.n_neurons, device=q.device)
        e[:, -1] = 1.0
        r_global = self.memory.read(e) if self.cfg.global_unit else torch.zeros_like(r_direct)
        H0 = self.enc_query(torch.cat([self.key_emb(query), r_direct, r_global], -1))
        logits, H, steps = self.workspace(H0, self.memory, auditor)
        self._last_steps = steps
        return logits

    @torch.no_grad()
    def predict(self, demo_keys, demo_vals, query, auditor=None, check_weights=True):
        """Inference: S updates from demos, weights frozen; ALWAYS audited [6]."""
        auditor = auditor or self.auditor
        was = self.training
        self.eval()
        fp0 = param_fingerprint(self) if check_weights else None
        t0 = time.perf_counter()
        logits = self(demo_keys, demo_vals, query, auditor)
        ms = 1000 * (time.perf_counter() - t0)
        fp1 = param_fingerprint(self) if check_weights else None
        steps = self._last_steps.float()
        st = self.memory.stats()
        auditor.log_predict(batch=int(query.shape[0]), latency_ms=ms,
                            latent_steps_mean=steps.mean().item(),
                            early_exit_frac=(steps < self.cfg.n_latent_steps).float().mean().item(),
                            S_fro_norm=st["S_fro_norm_mean"], S_writes=st["n_writes"],
                            state_bytes=st["state_bytes"],
                            weights_unchanged=(fp0 == fp1) if check_weights else None,
                            param_sha256=fp1)
        self.train(was)
        return {"logits": logits, "pred": logits.argmax(-1), "steps_used": self._last_steps,
                "latency_ms": ms, "weights_unchanged": fp0 == fp1, "fingerprint": fp1,
                "memory": st}

    def state_bytes_per_episode(self):
        return 4 * (self.n_neurons * self.cfg.d_value + self.n_neurons)


class PlasticReadout:
    """Online side of CDLR on a frozen backbone: [5] adapter + [2] episodic S (+ [3] bank).

    use_bank=False is the 'Hebbian-only continual' baseline (adapter + fast S only).
    """

    def __init__(self, cfg, n_features, use_bank=True):
        V = cfg.vocab_size
        self.cfg = cfg
        self.adapter = LocalAdapter(n_features, V, cfg.head_lr, cfg.head_decay, cfg.trace_gamma, cfg.seed)
        self.S = StreamS(n_features, V, cfg.ep_eta, cfg.ep_decay)
        self.bank = PrototypeBank(V, cfg.bank_alpha, cfg.bank_merge_sim, cfg.bank_gate_acc,
                                  cfg.replay_per_slot, cfg.seed) if use_bank else None
        self.support = (None, None)

    def logits(self, phi, slot=None, S=None):
        S = S or self.S
        out = self.adapter.logits(phi) + self.cfg.ep_alpha * S.read(phi)
        if self.bank is not None:
            out = out + self.bank.bonus(phi, slot)
        return out

    def select(self, phi, y):
        if self.bank is None:
            return None, []
        return self.bank.select(phi, y)

    @torch.no_grad()
    def step(self, phi, y, auditor=None):
        """Prequential: predict with current state, then local updates (no autograd)."""
        slot, accs = self.select(*self.support)
        lg = self.logits(phi, slot)
        loss = F.cross_entropy(lg, y).item()
        acc = (lg.argmax(-1) == y).float().mean().item()
        info = self.adapter.local_step(phi, lg.softmax(-1), y)
        self.S.write(phi, y)
        if self.bank is not None:
            self.bank.observe(phi, y)
        self.support = (phi, y)
        if auditor is not None:
            auditor.log("adapter_step", loss=loss, acc=acc, slot=slot, slot_support_acc=accs,
                        S_writes=self.S.mem.state.n_writes, **info)
        return loss, acc

    @torch.no_grad()
    def end_phase(self, auditor=None):
        if self.bank is None:
            return None
        info = self.bank.consolidate(self.S)
        if auditor is not None:
            auditor.log("consolidate", **info)
        return info

    @torch.no_grad()
    def evaluate(self, phi, y, sup_phi=None, sup_y=None):
        """Held-out eval. Support (if given) is written into a COPY of S and used for
        slot selection — identical information for both arms; nothing persists."""
        S = self.S
        if sup_phi is not None:
            S = self.S.fork()
            S.write(sup_phi, sup_y)
        slot, accs = self.select(sup_phi, sup_y) if sup_phi is not None else (None, [])
        lg = self.logits(phi, slot, S)
        return {"loss": F.cross_entropy(lg, y).item(), "acc": (lg.argmax(-1) == y).float().mean().item(),
                "slot": slot}

    def nbytes(self):
        n = 4 * (self.adapter.W.numel() + self.adapter.b.numel()) + self.S.mem.state.nbytes()
        if self.bank is not None:
            n += self.bank.nbytes() + self.bank.buffer.nbytes()
        return n

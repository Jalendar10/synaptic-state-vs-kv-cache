"""Toy tasks shared by every CDLR feature.

* Episodic few-shot (alrs.tasks, reused as-is): fresh key->value map per episode,
  K demos written into S, answer a query  -> exercises [1][2][4][6] and the arena [7].
* Continual stream A->B->A: tasks are fixed random permutations of the vocab over
  the SAME inputs (direct interference)  -> exercises [3][5] + forgetting metrics.
* Arena encoding: [k1, V+v1, ..., kK, V+vK, 2V, q] -> predict target at last position.
"""
from __future__ import annotations

import torch

from . import _paths  # noqa: F401
from alrs.tasks import TASKS, make_batch, make_dataset  # noqa: F401  reused as-is


class ContinualStream:
    def __init__(self, cfg, names=("A", "B"), seeds=(202, 303)):
        self.cfg = cfg
        V = cfg.vocab_size
        self.perm = {n: torch.randperm(V, generator=torch.Generator().manual_seed(s))
                     for n, s in zip(names, seeds)}
        ge = torch.Generator().manual_seed(10_000 + cfg.seed)
        self.eval_x = {n: torch.randint(0, V, (4 * cfg.cont_batch,), generator=ge) for n in names}
        self.support_x = {n: torch.randint(0, V, (cfg.support_size,), generator=ge) for n in names}
        self.g = torch.Generator().manual_seed(20_000 + cfg.seed)

    def target(self, name, x):
        return self.perm[name][x]

    def batch(self, name):
        x = torch.randint(0, self.cfg.vocab_size, (self.cfg.cont_batch,), generator=self.g)
        return x, self.target(name, x)


def arena_sequences(batch, V):
    k, v, q = batch["demo_keys"], batch["demo_vals"], batch["query"]
    B, K = k.shape
    inter = torch.stack([k, v + V], -1).reshape(B, 2 * K)
    seq = torch.cat([inter, torch.full((B, 1), 2 * V), q[:, None]], 1)
    return seq, batch["target"]

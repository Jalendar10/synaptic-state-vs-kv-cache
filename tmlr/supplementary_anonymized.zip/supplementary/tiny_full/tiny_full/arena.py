"""Tiny Arena hook (feature 7): CDLR vs a tiny Transformer on the SAME episodic task.

Same protocol for both: same task generator, same #steps, batch, lr, AdamW, same
fixed eval set. Reported per model:
  accuracy, params, memory_bytes = param_bytes + per-episode inference state bytes
  (CDLR: fixed-size S, independent of K;  Transformer: KV cache 2*L*T*d*4),
  latency_ms (mean wall time of one batched predict on CPU), and
  efficiency = accuracy / (memory_KB * latency_ms)   (higher is better).
The Transformer is imported from ../arena (arena.models.transformer.TinyTransformer).
"""
from __future__ import annotations

import time
from types import SimpleNamespace

import torch
import torch.nn.functional as F

from . import _paths  # noqa: F401
from .tasks import arena_sequences, make_batch, make_dataset

try:
    from arena.models.transformer import TinyTransformer
    _ARENA_ERR = None
except Exception as e:  # pragma: no cover
    TinyTransformer, _ARENA_ERR = None, e


def tiny_transformer(cfg):
    if TinyTransformer is None:
        raise ImportError(f"arena not importable: {_ARENA_ERR}")
    tcfg = SimpleNamespace(vocab_size=2 * cfg.vocab_size + 1, n_embd=cfg.n_embd, n_head=cfg.n_head,
                           n_layer=cfg.n_layer, block_size=2 * cfg.n_demos + 2, dropout=0.0, ffn_mult=4.0)
    return TinyTransformer(tcfg), tcfg


def _latency(fn, reps=5):
    fn()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    return 1000 * (time.perf_counter() - t0) / reps


def train_transformer(cfg, steps):
    torch.manual_seed(cfg.seed)
    m, tcfg = tiny_transformer(cfg)
    opt = torch.optim.AdamW(m.parameters(), lr=cfg.lr, weight_decay=0.01)
    g = torch.Generator().manual_seed(cfg.seed + 1)
    for _ in range(steps):
        x, y = arena_sequences(make_batch(cfg.task, cfg.batch_size, cfg.n_demos, cfg.vocab_size, g),
                               cfg.vocab_size)
        logits, _ = m(x)
        loss = F.cross_entropy(logits[:, -1, :cfg.vocab_size], y)
        opt.zero_grad(); loss.backward(); opt.step()
    return m, tcfg


@torch.no_grad()
def compare(cdlr, cfg, steps=None, n_eval=256):
    steps = steps or cfg.train_steps   # same budget as CDLR slow training
    ev = make_dataset(cfg.task, n_eval, cfg.n_demos, cfg.vocab_size, seed=999)
    rows = {}
    # CDLR (already trained by train.py with the same budget)
    cdlr.eval()
    out = cdlr.predict(ev["demo_keys"], ev["demo_vals"], ev["query"])
    acc = (out["pred"] == ev["target"]).float().mean().item()
    lat = _latency(lambda: cdlr(ev["demo_keys"], ev["demo_vals"], ev["query"]))
    pb = 4 * sum(p.numel() for p in cdlr.parameters())
    sb = cdlr.state_bytes_per_episode()
    rows["cdlr"] = {"accuracy": acc, "params": pb // 4, "param_bytes": pb, "state_bytes_per_episode": sb,
                    "memory_bytes": pb + sb, "latency_ms": lat,
                    "latent_steps_mean": out["steps_used"].float().mean().item()}
    # tiny Transformer, same task / steps / optimiser
    with torch.enable_grad():
        tf, tcfg = train_transformer(cfg, steps)
    tf.eval()
    x, y = arena_sequences(ev, cfg.vocab_size)
    acc = (tf(x)[0][:, -1, :cfg.vocab_size].argmax(-1) == y).float().mean().item()
    lat = _latency(lambda: tf(x))
    pb = 4 * sum(p.numel() for p in tf.parameters())
    sb = 4 * 2 * tcfg.n_layer * x.shape[1] * tcfg.n_embd
    rows["tiny_transformer"] = {"accuracy": acc, "params": pb // 4, "param_bytes": pb,
                                "state_bytes_per_episode": sb, "memory_bytes": pb + sb, "latency_ms": lat}
    for r in rows.values():
        r["efficiency_acc_per_KB_ms"] = r["accuracy"] / (r["memory_bytes"] / 1024 * r["latency_ms"])
    return {"task": cfg.task, "train_steps_each": steps, "n_eval": n_eval, "models": rows,
            "note": "toy CPU comparison; state bytes: CDLR S is constant in K, Transformer KV grows with K"}

"""Slow consolidated prototype bank + tiny replay buffer (feature 3, anti-forgetting).

Dual timescale:
  fast  : episodic S (StreamS) — damped Hebbian, tracks the CURRENT task, forgets.
  slow  : PrototypeBank — at consolidation ("sleep") the class prototypes read out of
          S columns are merged with class means re-computed from a tiny reservoir
          replay buffer, then either MERGED into a matching slot (cos-sim >= thr) or
          written to a NEW slot. Slots are never overwritten by a different task.
Task ids are never given to the model: a slot is selected by how well it explains
a small labelled support set (the previous batch in the stream, or a support batch
at evaluation). If no slot explains it (acc < gate), no slot is used.
    bonus logits = bank_alpha * phi @ P_slot^T
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def _unit(x):
    return x / x.norm(dim=-1, keepdim=True).clamp_min(1e-8)


class ReplayBuffer:
    """Reservoir sample of (phi, y) for the current consolidation window."""

    def __init__(self, capacity, seed=0):
        self.cap = capacity
        self.g = torch.Generator().manual_seed(seed)
        self.clear()

    def clear(self):
        self.phi, self.y, self.seen = [], [], 0

    def add(self, phi, y):
        for p, t in zip(phi, y):
            self.seen += 1
            if len(self.phi) < self.cap:
                self.phi.append(p.clone()); self.y.append(t.clone())
            else:
                j = int(torch.randint(0, self.seen, (1,), generator=self.g))
                if j < self.cap:
                    self.phi[j], self.y[j] = p.clone(), t.clone()

    def tensors(self):
        if not self.phi:
            return None, None
        return torch.stack(self.phi), torch.stack(self.y)

    def nbytes(self):
        return sum(p.numel() * 4 + 8 for p in self.phi)


class PrototypeBank:
    def __init__(self, n_classes, alpha, merge_sim, gate_acc, replay_capacity, seed=0):
        self.V, self.alpha, self.merge_sim, self.gate = n_classes, alpha, merge_sim, gate_acc
        self.cap, self.seed = replay_capacity, seed
        self.slots: list[dict] = []
        self.buffer = ReplayBuffer(replay_capacity, seed)

    # ---- replay --------------------------------------------------------
    def observe(self, phi, y):
        self.buffer.add(phi, y)

    def _replay_prototypes(self, phi, y):
        P = torch.zeros(self.V, phi.shape[1])
        P.index_add_(0, y, phi)
        has = torch.bincount(y, minlength=self.V) > 0
        return _unit(P), has

    # ---- consolidation (S + replay -> slow slot) -----------------------
    @torch.no_grad()
    def consolidate(self, stream_S):
        P_S = stream_S.prototypes()                          # (V, n) from fast S
        phi, y = self.buffer.tensors()
        if phi is not None:
            P_R, has = self._replay_prototypes(phi, y)
            P_new = _unit(torch.where(has[:, None], 0.5 * P_S + 0.5 * P_R, P_S))
        else:
            P_new = P_S
        sims = [self.similarity(s["P"], P_new) for s in self.slots]
        if sims and max(sims) >= self.merge_sim:
            i = int(torch.tensor(sims).argmax())
            s = self.slots[i]
            k = s["n_merges"]
            s["P"] = _unit((k * s["P"] + P_new) / (k + 1))
            s["n_merges"] += 1
            action = "merge"
        else:
            self.slots.append({"P": P_new, "n_merges": 1})
            i, action = len(self.slots) - 1, "new_slot"
        info = {"action": action, "slot": i, "n_slots": len(self.slots),
                "sims_to_existing": [round(float(v), 4) for v in sims],
                "replay_size": 0 if phi is None else int(phi.shape[0]),
                "bank_bytes": self.nbytes()}
        self.buffer.clear()
        return info

    @staticmethod
    def similarity(P1, P2):
        return float((P1 * P2).sum(-1).mean())

    # ---- recall --------------------------------------------------------
    @torch.no_grad()
    def select(self, phi, y):
        """Pick the slot that best explains a labelled support set; None if none fits."""
        if not self.slots or phi is None:
            return None, []
        accs = [float(((phi @ s["P"].T).argmax(-1) == y).float().mean()) for s in self.slots]
        best = int(torch.tensor(accs).argmax())
        return (best if accs[best] >= self.gate else None), accs

    def bonus(self, phi, slot):
        if slot is None:
            return torch.zeros(phi.shape[0], self.V)
        return self.alpha * (phi @ self.slots[slot]["P"].T)

    def nbytes(self):
        return sum(s["P"].numel() * 4 for s in self.slots)

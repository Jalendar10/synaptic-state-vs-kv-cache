"""Latent workspace with R reasoning steps + confidence early-exit (feature 4).

    H_0     = E(x*, S)                 (model.py)
    H_{r+1} = H_r + F([H_r ; read(S, q_r)]),  q_r = kWTA(W_q H_r)  (re-query S every step)
    y_hat   = G(H_R)

Same weights each loop (alrs LatentReasoner pattern; kwta imported from alrs).
Early exit (inference only): a sample stops looping once max softmax(G(H_r)) >=
exit_conf; its H is frozen and the steps actually used are logged per sample.
"""
from __future__ import annotations

import torch
from torch import nn

from . import _paths  # noqa: F401
from alrs.latent import kwta  # reused as-is


class LatentWorkspace(nn.Module):
    def __init__(self, d_hidden, d_value, n_neurons, n_out, n_steps=3, sparsity=0.05,
                 early_exit=True, exit_conf=0.9):
        super().__init__()
        self.n_steps, self.sparsity = n_steps, sparsity
        self.early_exit, self.exit_conf = early_exit, exit_conf
        self.query_proj = nn.Linear(d_hidden, n_neurons)
        self.norm = nn.LayerNorm(d_hidden + d_value)
        self.f = nn.Sequential(nn.Linear(d_hidden + d_value, 2 * d_hidden), nn.GELU(),
                               nn.Linear(2 * d_hidden, d_hidden))
        self.out_norm = nn.LayerNorm(d_hidden)
        self.readout = nn.Linear(d_hidden, n_out)

    def requery(self, H):
        q = kwta(self.query_proj(H), self.sparsity)
        return q / q.norm(dim=-1, keepdim=True).clamp_min(1e-6)

    def head(self, H):
        return self.readout(self.out_norm(H))

    def forward(self, H0, memory, auditor=None):
        H = H0
        B = H.shape[0]
        active = torch.ones(B, dtype=torch.bool, device=H.device)
        steps_used = torch.zeros(B, dtype=torch.long, device=H.device)
        use_exit = self.early_exit and not self.training
        for r in range(self.n_steps):
            q = self.requery(H)
            read = memory.read(q)
            H_next = H + self.f(self.norm(torch.cat([H, read], -1)))
            if use_exit:
                H_next = torch.where(active[:, None], H_next, H)
            steps_used = steps_used + active.long()
            conf = self.head(H_next).softmax(-1).max(-1).values
            if auditor is not None:
                auditor.log_latent(r, H, H_next, q, read, conf, active)
            H = H_next
            if use_exit:
                active = active & (conf < self.exit_conf)
                if not active.any():
                    break
        return self.head(H), H, steps_used

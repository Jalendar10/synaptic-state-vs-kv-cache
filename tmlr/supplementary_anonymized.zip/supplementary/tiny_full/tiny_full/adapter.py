"""Fast local Hebbian / eligibility adapter head (feature 5).

logits = W phi + b  (+ alpha_S * read(S, phi)  + alpha_P * P_slot phi  in CDLR)

W, b are updated ONLY by continual's three-factor delta rule with an optional
eligibility trace (imported unchanged from continual.hebbian_update):
    e_t = gamma e_{t-1} + phi_t ;  dW = eta (y - p) (x) e  - eta*wd*W
No autograd, no BPTT, backbone frozen.
"""
from __future__ import annotations

import torch

from . import _paths  # noqa: F401
from continual.hebbian_update import delta_rule_update, normalise  # noqa: F401  reused as-is


class LocalAdapter:
    def __init__(self, n_features, n_classes, lr, wd, gamma, seed=0):
        g = torch.Generator().manual_seed(seed)
        self.W = torch.randn(n_classes, n_features, generator=g) * 0.01
        self.b = torch.zeros(n_classes)
        self.lr, self.wd, self.gamma = lr, wd, gamma
        self.n_updates = 0

    def logits(self, phi):
        return phi @ self.W.T + self.b

    @torch.no_grad()
    def local_step(self, phi, probs, y):
        """phi:(M,F) probs:(M,V) y:(M,) — treated as M length-1 windows."""
        mask = torch.ones_like(y, dtype=torch.bool)[:, None]
        W0 = self.W.norm().item()
        delta_rule_update(self.W, self.b, phi[:, None], probs[:, None], y[:, None], mask,
                          self.lr, self.wd, self.gamma)
        self.n_updates += 1
        return {"W_norm_before": W0, "W_norm_after": self.W.norm().item()}

    def clone(self):
        c = LocalAdapter.__new__(LocalAdapter)
        c.__dict__ = {k: (v.clone() if torch.is_tensor(v) else v) for k, v in self.__dict__.items()}
        return c

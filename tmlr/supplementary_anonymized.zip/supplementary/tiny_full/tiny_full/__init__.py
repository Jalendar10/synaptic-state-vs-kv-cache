"""Tiny-Full = CDLR, the Compact Dual-Timescale Latent Reasoner.

Design rule: "smaller not bigger — small with all features as bigger."
One tiny CPU model exposing every capability of the ALRS -> Arena -> Continual stack:
  1 sparse positive backbone (Pathway BDH tiny | builtin)   2 fast episodic Hebbian S
  3 slow consolidated prototype bank + tiny replay          4 latent workspace, R steps, early exit
  5 local Hebbian/eligibility adapter                       6 synapse/activation audit on every predict
  7 tiny Arena hook vs tiny Transformer (accuracy x memory_bytes x latency_ms)
"""
from tiny_full.config import TinyFullConfig, make_config
from tiny_full.model import CDLR, PlasticReadout

__all__ = ["TinyFullConfig", "make_config", "CDLR", "PlasticReadout"]
__version__ = "0.1.0"

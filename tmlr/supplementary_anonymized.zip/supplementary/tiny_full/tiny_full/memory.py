"""Fast episodic Hebbian memory S (feature 2).

* `HebbianMemory` is imported UNCHANGED from alrs: per-episode S (B, n, d_value),
  S <- lambda S + eta phi(k) (x) v ; read = q^T S / (q^T z + eps).
  It is pure state: updates never touch nn.Parameters (proved by param fingerprint).
* `StreamS` reuses the same HebbianMemory for the continual stream: one shared S
  (n_features x vocab) written with phi(x) (x) onehot(y). Its columns are the raw
  material the consolidator merges into the slow prototype bank.
"""
from __future__ import annotations

import math

import torch
import torch.nn.functional as F

from . import _paths  # noqa: F401
from alrs.hebbian_memory import HebbianMemory, MemoryState  # noqa: F401  (reused as-is)


class StreamS:
    """Fixed-gain episodic S over a token stream (batch-1 HebbianMemory state)."""

    def __init__(self, n_features: int, n_classes: int, eta: float, decay: float):
        self.mem = HebbianMemory(n_features, n_classes, eta_init=eta, decay_init=decay)
        self.mem.requires_grad_(False)
        self.n_classes = n_classes
        self._args = (n_features, n_classes, eta, decay)
        self.reset()

    def fork(self):
        """Cheap copy sharing the (immutable, out-of-place-updated) state."""
        c = StreamS(*self._args)
        c.mem.state = self.mem.state
        return c

    def reset(self):
        self.mem.reset(1)

    @torch.no_grad()
    def write(self, phi: torch.Tensor, y: torch.Tensor):
        """phi: (M, n) >= 0, y: (M,) -> one damped Hebbian write of the batch sum."""
        st = self.mem.state
        lam, eta = self.mem.decay, self.mem.eta
        v = F.one_hot(y, self.n_classes).float()
        dS = (phi.T @ v / max(1, phi.shape[0])).unsqueeze(0)
        dz = phi.mean(0, keepdim=True)
        self.mem.state = MemoryState(S=lam * st.S + eta * dS, z=lam * st.z + eta * dz,
                                     n_writes=st.n_writes + 1)

    @torch.no_grad()
    def read(self, phi: torch.Tensor) -> torch.Tensor:
        """(M, n) -> (M, V) class evidence in [0, 1]."""
        st = self.mem.state
        num = phi @ st.S[0]
        den = (phi * st.z[0]).sum(-1, keepdim=True) + self.mem.eps
        return num / den

    def prototypes(self) -> torch.Tensor:
        """(V, n) unit-norm class prototypes from S columns (for consolidation)."""
        P = self.mem.state.S[0].T.clone()
        return P / P.norm(dim=-1, keepdim=True).clamp_min(1e-8)

    def stats(self):
        return self.mem.stats()

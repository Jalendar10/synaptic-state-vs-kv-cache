"""Synapse / activation audit (feature 6) — logged on EVERY predict.

Events: encode (sparsity, entropy, top units), memory_update (||S||, neurons
written, state bytes), latent_step (||dH||, read norm, re-query sparsity,
confidence, active samples), predict (steps used, early-exit rate, param
fingerprint), adapter_step, consolidate, continual_eval. Stats helper
`activation_stats` is imported unchanged from alrs.synapse_audit.
"""
from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

import torch

from . import _paths  # noqa: F401
from alrs.synapse_audit import activation_stats  # reused as-is

RUNS_DIR = Path(__file__).resolve().parents[1] / "runs"


class Auditor:
    def __init__(self, name="tiny_full_audit", top_k=8, max_events=5000):
        self.name, self.top_k, self.max_events = name, top_k, max_events
        self.events: list[dict] = []
        self.meta: dict = {}
        self.counts: dict = {}
        self.unit_hits = None

    def _add(self, ev):
        self.counts[ev["event"]] = self.counts.get(ev["event"], 0) + 1
        if len(self.events) < self.max_events:
            self.events.append(ev)

    def _hit(self, x):
        h = (x.detach().reshape(-1, x.shape[-1]) > 0).float().sum(0)
        self.unit_hits = h if self.unit_hits is None or self.unit_hits.shape != h.shape \
            else self.unit_hits + h

    def log_encoder(self, tag, raw, sparse):
        self._hit(sparse)
        self._add({"event": "encode", "tag": tag, "raw": activation_stats(raw, self.top_k),
                   "sparse": activation_stats(sparse, self.top_k)})

    def log_update(self, idx, key, value, memory):
        self._add({"event": "memory_update", "demo_index": idx,
                   "key": activation_stats(key, self.top_k),
                   "value_norm": value.detach().norm(dim=-1).mean().item(),
                   "memory": memory.stats()})

    def log_latent(self, step, H, H_next, q, read, conf, active):
        self._add({"event": "latent_step", "step": step,
                   "H_norm": H.detach().norm(dim=-1).mean().item(),
                   "delta_H_norm": (H_next - H).detach().norm(dim=-1).mean().item(),
                   "read_norm": read.detach().norm(dim=-1).mean().item(),
                   "requery": activation_stats(q, self.top_k),
                   "conf_mean": conf.detach().mean().item(),
                   "active_frac": active.float().mean().item()})

    def log_predict(self, **kw):
        self._add({"event": "predict", **kw})

    def log(self, event, **kw):
        self._add({"event": event, **kw})

    def summary(self):
        s = {"event_counts": self.counts}
        if self.unit_hits is not None:
            h = self.unit_hits
            s["units_ever_active_frac"] = (h > 0).float().mean().item()
            s["top_units_by_hits"] = h.topk(min(10, h.numel())).indices.tolist()
        lat = [e for e in self.events if e["event"] == "latent_step"]
        if lat:
            s["mean_delta_H_by_step"] = {}
            for e in lat:
                s["mean_delta_H_by_step"].setdefault(e["step"], []).append(e["delta_H_norm"])
            s["mean_delta_H_by_step"] = {k: sum(v) / len(v) for k, v in s["mean_delta_H_by_step"].items()}
        return s

    def save(self, path=None):
        path = Path(path) if path else RUNS_DIR / f"{self.name}_{_dt.datetime.now():%Y%m%d_%H%M%S}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"name": self.name, "meta": self.meta, "summary": self.summary(),
                                    "events": self.events}, indent=1, default=float))
        return path

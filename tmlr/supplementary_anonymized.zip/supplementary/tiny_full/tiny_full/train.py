"""End-to-end Tiny-Full (CDLR) run: every feature, one small model.

  1. slow training   : episodic few-shot task, backprop through demos (alrs protocol)
  2. inference demo  : S updated by demos, weights frozen (sha256 fingerprint), R latent
                       steps + early exit, audited predict
  3. continual       : frozen backbone, A->B->A stream; 'hebbian_only' (adapter + fast S)
                       vs 'cdlr' (adapter + fast S + consolidated prototype bank w/ replay)
  4. arena           : CDLR vs tiny Transformer (accuracy x memory_bytes x latency_ms)
  5. audit JSON + summary JSON under runs/

  python -m tiny_full.train --preset tiny [--encoder builtin] [--no-arena]
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tiny_full.audit import RUNS_DIR, Auditor  # noqa: E402
from tiny_full.config import make_config  # noqa: E402
from tiny_full.model import CDLR, PlasticReadout, count_params, param_fingerprint  # noqa: E402
from tiny_full.tasks import ContinualStream, make_batch, make_dataset  # noqa: E402


def train_slow(model, cfg, log=print):
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=0.01)
    g = torch.Generator().manual_seed(cfg.seed + 1)
    model.train()
    hist = []
    for s in range(cfg.train_steps):
        b = make_batch(cfg.task, cfg.batch_size, cfg.n_demos, cfg.vocab_size, g)
        logits = model(b["demo_keys"], b["demo_vals"], b["query"])
        loss = F.cross_entropy(logits, b["target"])
        opt.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if s % 50 == 0 or s == cfg.train_steps - 1:
            acc = (logits.argmax(-1) == b["target"]).float().mean().item()
            hist.append({"step": s, "loss": loss.item(), "acc": acc})
    return hist


@torch.no_grad()
def inference_demo(model, cfg, auditor):
    ev = make_dataset(cfg.task, 128, cfg.n_demos, cfg.vocab_size, seed=123)
    fp_before = param_fingerprint(model)
    out = model.predict(ev["demo_keys"], ev["demo_vals"], ev["query"], auditor=auditor)
    fp_after = param_fingerprint(model)
    acc = (out["pred"] == ev["target"]).float().mean().item()
    # no-demo control: same queries with an empty S -> shows the answer lives in S
    empty = {k: v[:, :0] for k, v in ev.items() if k.startswith("demo")}
    ctrl = model.predict(empty["demo_keys"], empty["demo_vals"], ev["query"], auditor=auditor)
    acc_ctrl = (ctrl["pred"] == ev["target"]).float().mean().item()
    return {"acc_with_demos": acc, "acc_without_demos": acc_ctrl, "chance": 1 / cfg.vocab_size,
            "weights_unchanged": fp_before == fp_after and out["weights_unchanged"],
            "param_sha256": fp_after, "S_n_writes": out["memory"]["n_writes"],
            "S_fro_norm_mean": out["memory"]["S_fro_norm_mean"],
            "S_state_bytes": out["memory"]["state_bytes"],
            "latent_steps_max": cfg.n_latent_steps,
            "latent_steps_mean": out["steps_used"].float().mean().item(),
            "early_exit_frac": (out["steps_used"] < cfg.n_latent_steps).float().mean().item(),
            "latency_ms": out["latency_ms"]}


@torch.no_grad()
def continual_compare(model, cfg, auditor, phases=("A", "B", "A")):
    model.eval()
    fp0 = param_fingerprint(model)
    stream = ContinualStream(cfg)
    feats = lambda x: model.features(x)                           # frozen backbone
    eval_phi = {n: feats(x) for n, x in stream.eval_x.items()}
    sup_phi = {n: feats(x) for n, x in stream.support_x.items()}
    arms = {"hebbian_only": PlasticReadout(cfg, model.n_features, use_bank=False),
            "cdlr": PlasticReadout(cfg, model.n_features, use_bank=True)}
    batches = [[stream.batch(t) for _ in range(cfg.steps_per_phase)] for t in phases]  # identical stream
    res = {}
    for name, arm in arms.items():
        aud = auditor if name == "cdlr" else None
        ph_log = []
        for pi, (task, bl) in enumerate(zip(phases, batches)):
            ol, oa = [], []
            for x, y in bl:
                l, a = arm.step(feats(x), y, aud)
                ol.append(l); oa.append(a)
            cons = arm.end_phase(aud)
            ev = {n: arm.evaluate(eval_phi[n], stream.target(n, stream.eval_x[n]),
                                  sup_phi[n], stream.target(n, stream.support_x[n]))
                  for n in stream.perm}
            ph_log.append({"index": pi, "task": task, "online_loss": sum(ol) / len(ol),
                           "online_acc": sum(oa) / len(oa),
                           "first_k_online_loss": sum(ol[:cfg.relearn_k]) / cfg.relearn_k,
                           "first_k_online_acc": sum(oa[:cfg.relearn_k]) / cfg.relearn_k,
                           "end_eval": ev, "consolidation": cons})
            if aud is not None:
                aud.log("continual_eval", arm=name, phase=pi, task=task, eval=ev)
        a0, a1, a2 = (p["end_eval"]["A"]["acc"] for p in ph_log)
        res[name] = {"phases": ph_log, "state_bytes": arm.nbytes(),
                     "A_acc_after_A": a0, "A_acc_after_B": a1, "A_acc_final": a2,
                     "B_acc_after_B": ph_log[1]["end_eval"]["B"]["acc"],
                     "forgetting_A_acc": a0 - a1,                       # >0 = forgot
                     "retention_A": a1 / max(a0, 1e-8),
                     "relearn_first_k_acc_A": ph_log[2]["first_k_online_acc"],
                     "relearn_first_k_loss_A": ph_log[2]["first_k_online_loss"]}
    res["weights_unchanged"] = fp0 == param_fingerprint(model)
    res["cdlr_beats_hebbian_only_on_A_retention"] = \
        res["cdlr"]["A_acc_after_B"] > res["hebbian_only"]["A_acc_after_B"]
    res["protocol"] = ("same frozen backbone, same batch stream; held-out eval after each phase with a "
                       f"{cfg.support_size}-token labelled support set written into a COPY of S (both arms) "
                       "and used for bank-slot selection (cdlr only); no task ids given")
    return res


def run_all(cfg, out_dir=None, log=print, do_arena=None):
    torch.set_num_threads(cfg.threads)
    torch.manual_seed(cfg.seed)
    out_dir = Path(out_dir or RUNS_DIR / f"run_{cfg.encoder}_{_dt.datetime.now():%Y%m%d_%H%M%S}")
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg.to_json(out_dir / "config.json")
    t0 = time.time()
    model = CDLR(cfg)
    auditor = Auditor(f"audit_{cfg.encoder}")
    model.auditor = auditor
    summary = {"architecture": "CDLR (Compact Dual-Timescale Latent Reasoner) = Tiny-Full",
               "encoder": cfg.encoder, "params": count_params(model), "n_features": model.n_features}
    t = time.time(); summary["slow_training"] = train_slow(model, cfg); summary["slow_training_s"] = time.time() - t
    log(f"[1-train] {cfg.encoder} params={summary['params']['total']} last={summary['slow_training'][-1]}")
    t = time.time(); summary["inference"] = inference_demo(model, cfg, auditor); summary["inference_s"] = time.time() - t
    log(f"[2/4-infer] {json.dumps({k: v for k, v in summary['inference'].items() if k != 'param_sha256'})}")
    t = time.time(); summary["continual"] = continual_compare(model, cfg, auditor); summary["continual_s"] = time.time() - t
    c = summary["continual"]
    for arm in ("hebbian_only", "cdlr"):
        r = c[arm]
        log(f"[3/5-continual] {arm:12s} A@A={r['A_acc_after_A']:.3f} A@B={r['A_acc_after_B']:.3f} "
            f"B@B={r['B_acc_after_B']:.3f} A@final={r['A_acc_final']:.3f} forget={r['forgetting_A_acc']:.3f} "
            f"relearn_k_acc={r['relearn_first_k_acc_A']:.3f} bytes={r['state_bytes']}")
    if cfg.arena if do_arena is None else do_arena:
        from tiny_full.arena import compare
        t = time.time(); summary["arena"] = compare(model, cfg); summary["arena_s"] = time.time() - t
        for m, r in summary["arena"]["models"].items():
            log(f"[7-arena] {m:16s} acc={r['accuracy']:.3f} mem={r['memory_bytes']}B "
                f"lat={r['latency_ms']:.2f}ms eff={r['efficiency_acc_per_KB_ms']:.2e}")
    auditor.meta = {"config": cfg.to_dict(), "param_sha256": param_fingerprint(model)}
    summary["audit_path"] = str(auditor.save(out_dir / "audit.json"))
    summary["wall_s"] = time.time() - t0
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=float))
    log(f"[6-audit] {summary['audit_path']}  events={auditor.counts}")
    return summary, model, out_dir


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="tiny")
    ap.add_argument("--encoder", choices=["bdh", "builtin"])
    ap.add_argument("--task")
    ap.add_argument("--seed", type=int)
    ap.add_argument("--no-arena", action="store_true")
    ap.add_argument("--no-early-exit", action="store_true")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    cfg = make_config(a.preset, encoder=a.encoder, task=a.task, seed=a.seed)
    if a.no_early_exit:
        cfg.early_exit = False
    s, _, out = run_all(cfg, a.out, do_arena=not a.no_arena)
    print(f"summary -> {out / 'summary.json'}  ({s['wall_s']:.1f}s)")


if __name__ == "__main__":
    main()

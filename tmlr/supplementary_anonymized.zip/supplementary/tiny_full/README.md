# Tiny-Full — CDLR: Compact Dual-Timescale Latent Reasoner

**The advanced design under the user's rule: _"smaller not bigger — small with all features as bigger."_**

One tiny, CPU-friendly model (default: BDH `n_embd=32`, `n_layer=2`, `n_head=2`, 256 sparse
neurons, R=3 latent steps, **~52k params**) that exposes *every* capability of the larger
ALRS → Arena → Continual stack. Nothing is stripped out to make it small; only the width shrinks.

Research prototype on toy tasks. It is **not** Pathway's BDH-CQ and makes no claim to close the
BDH paper's no-BPTT gap (§7.2).

## Feature checklist

| # | Capability | Status | Where |
|---|---|---|---|
| 1 | Sparse positive backbone: Pathway `bdh.py` (tiny config, imported **unchanged**) **or** builtin sparse encoder (`--encoder builtin`), then k-WTA (5%) + L2 | ✓ | `model.py` (encoders reused from `alrs.model`) |
| 2 | Fast episodic Hebbian memory **S**: demos write S at inference, weights frozen (sha256 fingerprint before = after) | ✓ | `memory.py` (`alrs.hebbian_memory.HebbianMemory` reused), `CDLR.forward/predict` |
| 3 | Slow consolidated **prototype bank** + tiny reservoir **replay** buffer: anti-forgetting (merge/replay from S); beats Hebbian-only on A retention in A→B→A | ✓ | `consolidate.py` |
| 4 | **Latent workspace**: R re-query steps over S, shared weights, per-sample confidence **early exit** | ✓ | `latent.py` (`alrs.latent.kwta` reused) |
| 5 | Fast **local Hebbian / eligibility adapter** head: three-factor delta rule, no autograd, no BPTT | ✓ | `adapter.py` (`continual.hebbian_update.delta_rule_update` reused) |
| 6 | **Synapse / activation audit** JSON on *every* `predict` (sparsity, entropy, top units, ‖S‖, ‖ΔH‖/step, early-exit, latency, weights-unchanged) plus adapter/consolidation events | ✓ | `audit.py` (`alrs.synapse_audit.activation_stats` reused) |
| 7 | **Tiny Arena hook**: vs tiny Transformer on the same task & budget, reporting accuracy × memory_bytes × latency_ms | ✓ | `arena.py` (`arena.models.transformer.TinyTransformer` reused) |

## Architecture

```
tokens ──► [1] sparse positive backbone φ (BDH tiny | builtin) ──► k-WTA, L2
             │
   episodic  │ demos (k,v):  S ← λS + η φ(k) ⊗ W(k,v)          [2] fast timescale (state only)
   reasoning │ query x*:     H0 = E(x*, read(S,φ(x*)), read(S,global))
             │               H_{r+1} = H_r + F([H_r ; read(S, kWTA(W_q H_r))])   r < R
             │               early-exit when max softmax G(H_r) ≥ 0.9          [4]
             │               ŷ = G(H_R)
             │
   online /  │ backbone & slow weights frozen
   continual │ logits = W φ + b                     [5] local delta/eligibility rule
             │        + α_S · read(S_stream, φ)     [2] fast episodic S (damped, tracks current task)
             │        + α_P · P_slot φ              [3] slow prototype bank (selected by support fit)
             │ end of phase ("sleep"): P_new = unit(½·S-columns + ½·replay class means)
             │                         merge into matching slot (cos ≥ 0.8) else new slot
             └─► [6] audit on every predict / adapter step / consolidation
```

Dual timescale: **S** is fast and forgets by design (decay λ); the **bank** is slow and
never overwritten by a different task. Task ids are never given: a slot is chosen by how well
it explains a small labelled support set (previous stream batch, or the support batch at eval);
below `bank_gate_acc` no slot is used.

## How Tiny-Full maps to the bigger stack

| Larger stack | Tiny-Full piece |
|---|---|
| `code/bdh` (Pathway BDH) | backbone [1], imported unchanged via `tiny_full/_paths.py` |
| `alrs/` (Hebbian S, latent loops, audit, episodic tasks, encoders) | [2] S, [4] workspace (+ early exit), [6] audit stats, episodic tasks |
| `continual/` (local adapter, A→B→A stream, forgetting metrics) | [5] adapter, `hebbian_only` baseline arm, forgetting / relearn metrics |
| new in Tiny-Full | [3] prototype bank + replay consolidation, early exit, audit-on-every-predict |
| `arena/` (tiny Transformer) | [7] `arena.py` — same task, steps, optimiser, eval set |

No file in `code/`, `alrs/`, `continual/`, or `arena/` is modified; they are imported read-only.

## Layout

```
tiny_full/
  README.md  requirements.txt
  tiny_full/
    __init__.py  _paths.py  config.py  model.py  memory.py  latent.py  adapter.py
    consolidate.py  audit.py  tasks.py  train.py  arena.py  smoke_test.py
  runs/        # smoke/ (summary.json, audit.json, audit_builtin.json, smoke_checks.json, config.json)
```

## Run

```bash
cd /workspace/bdh-research/tiny_full
../.venv/bin/python -m tiny_full.smoke_test                  # ~3-5 s CPU, exit 0 = all checks pass
../.venv/bin/python -m tiny_full.train --preset tiny         # default small run (all features)
../.venv/bin/python -m tiny_full.train --preset tiny --encoder builtin
../.venv/bin/python -m tiny_full.train --preset tiny --task shift --no-early-exit --no-arena
../.venv/bin/python -m tiny_full.train --preset long         # still small: n_embd=64, n_layer=3
```
Outputs: `runs/<run>/summary.json`, `audit.json`, `config.json`.

## Protocols

* **Episodic** (alrs `recall|shift|mixed`): a fresh key→value map every episode; K=4 demos go
  into S, then the model answers a query. Slow weights are trained by backprop through the demos;
  at inference only S changes. Control: the same queries with no demos (empty S) fall to chance.
* **Continual A→B→A**: A and B are random permutations of the same 16 inputs (full
  interference). The frozen backbone gives φ. Both arms see an identical batch stream and are
  scored prequentially. **hebbian_only** = adapter + fast S; **cdlr** = adapter + fast S + bank/replay.
  Held-out eval after each phase gives both arms the same 32-token labelled support set,
  written into a *copy* of S (cdlr also uses it to choose a slot). Logged: A acc after A / after B /
  final, forgetting = A@A − A@B, retention ratio, first-k relearn acc/loss on A's return, state bytes.
* **Arena**: CDLR vs tiny Transformer (`[k1,v1,…,kK,vK,SEP,q]`, same d / layers / heads, same
  steps, AdamW, lr, eval set). Reported per model: accuracy, params, memory_bytes = param bytes +
  per-episode inference state (CDLR S is constant in K; Transformer KV cache grows with K),
  latency_ms, and efficiency = acc / (KB × ms).

## Smoke result (CPU, seed 0, BDH backbone)

| check | result |
|---|---|
| memory S updated w/o weight change | 4 writes, ‖S‖≈11.6, sha256 unchanged; acc 1.00 with demos vs 0.086 without |
| latent steps + early exit | mean 1.23 / 3 steps (all samples exited early); builtin full-R path logs 3/3 |
| local adapter | 75 delta-rule steps, no autograd |
| A→B→A | A@B: **cdlr 1.000** vs hebbian_only 0.000 (forgetting 0.00 vs 1.00); first-5 relearn acc on A 0.80 vs 0.04; bank: new, new, merge |
| audit | `runs/smoke/audit.json` (encode/memory_update/latent_step/predict/adapter_step/consolidate events) |
| arena (150 steps each) | CDLR acc 0.996, 244 KB, ~28 ms · tiny Transformer acc 0.246, 114 KB, ~1 ms |

Caveats: this is a toy setup. At this budget the Transformer is undertrained, and it wins on
latency and efficiency: the BDH encoder runs one pass per demo, so it is the slower piece. The
retention win comes from the bank's support-based slot recall, so it assumes a few labelled
examples of the returning task are available.
